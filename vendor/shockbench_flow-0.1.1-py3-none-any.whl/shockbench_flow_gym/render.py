"""The network state drawn as a graph, from an observation and Static only (design §12 "Render (M3 wire)"; Q95).

A matplotlib ``Figure`` on the Agg canvas (never ``pyplot``, so no global figure state), networkx's drawing on a fixed
layout: x the node type in the order of the §9.2 vocabulary, y the rank within its type. Each edge is coloured by its
observed state at the instant t - 1: prohibited for every commodity it carries, or at capacity 0, red; capacity below
its nominal ``u0``, amber; open, grey; unobserved (``graph_now`` null, or an edge the coverage rung masks: its ``c``
and ``tau`` null, which marks a coupling edge too, whose ``u`` is always null; M3 attempt 1's gate, SPEC-M3-03), light
grey. Each chokepoint is coloured by its open fraction, the other nodes by type. No random draw anywhere.
"""

import networkx as nx
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg  # the Agg canvas, bound to its own Figure (no pyplot)
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.figure import Figure

from shockbench_flow.instance.schema import NODE_TYPES


WIDTH, HEIGHT, DPI = 640, 400, 100  # pixels and dots per inch of the image (a display choice, not a model value)
EDGE_COLOURS = {"closed": "#c0392b", "reduced": "#e67e22", "open": "#7f8c8d", "unobserved": "#d5d8dc"}
NODE_COLOURS = {
    "source": "#2e86c1",
    "terminal": "#5dade2",
    "grid": "#f4d03f",
    "chokepoint": "#ffffff",
    "material": "#a569bd",
    "fab": "#48c9b0",
    "osat": "#45b39d",
    "sink": "#34495e",
}
OPEN_MAP = LinearSegmentedColormap.from_list("open", ["#c0392b", "#f4d03f", "#27ae60"])  # 0 closed .. 1 open


def layout(static: dict) -> dict[int, tuple[float, float]]:
    """The fixed node positions: x the node type's index in ``NODE_TYPES``, y the rank within the type, centred."""
    by_type: dict[str, list[int]] = {}
    for i, t in enumerate(static["nodes"]["type"]):
        by_type.setdefault(t, []).append(i)
    pos = {}
    for t, nodes in by_type.items():
        for r, i in enumerate(nodes):
            pos[i] = (float(NODE_TYPES.index(t)), (len(nodes) - 1) / 2 - r)
    return pos


def edge_states(static: dict, obs: dict) -> list[str]:
    """The state of each edge (``EDGE_COLOURS`` keys) in the observation of the instant t - 1."""
    g = obs.get("graph_now")
    edges = static["edges"]
    if g is None:
        return ["unobserved"] * len(edges["id"])
    prohibited = set(zip(g["prohibited"]["edge"], g["prohibited"]["k"]))
    out = []
    for e, (K, u0) in enumerate(zip(edges["K"], edges["u0"])):
        u = g["u"][e]
        if K and all((e, k) in prohibited for k in K):
            out.append("closed")
        elif g["c"][e] is None or g["tau"][e] is None or (u0 is not None and u is None):  # masked (a coupling one too)
            out.append("unobserved")
        elif u is not None and u == 0:
            out.append("closed")
        elif u is not None and u0 is not None and u < u0:
            out.append("reduced")
        else:
            out.append("open")
    return out


def draw(static: dict, obs: dict) -> np.ndarray:
    """The image of the network state: uint8 (HEIGHT, WIDTH, 3) (module docstring)."""
    fig = Figure(figsize=(WIDTH / DPI, HEIGHT / DPI), dpi=DPI)
    canvas = FigureCanvasAgg(fig)
    ax = fig.add_axes((0.02, 0.02, 0.96, 0.86))
    ax.set_axis_off()
    pos = layout(static)
    types = static["nodes"]["type"]
    graph = nx.MultiDiGraph()
    graph.add_nodes_from(range(len(types)))
    edges = static["edges"]
    states = edge_states(static, obs)
    seen: dict[tuple[int, int], int] = {}
    for e, (a, b) in enumerate(zip(edges["tail"], edges["head"])):
        rank = seen.get((a, b), 0)  # parallel edges bend apart, in edge order
        seen[(a, b)] = rank + 1
        graph.add_edge(a, b, key=e)
        nx.draw_networkx_edges(
            graph,
            pos,
            edgelist=[(a, b, e)],
            ax=ax,
            edge_color=EDGE_COLOURS[states[e]],
            width=2.0,
            arrows=True,
            arrowsize=8,
            connectionstyle=f"arc3,rad={0.12 + 0.18 * rank}",
            node_size=260,
        )
    g = obs.get("graph_now")
    chk = [i for i, t in enumerate(types) if t == "chokepoint"]
    colours = [NODE_COLOURS[t] for t in types]
    if g is not None:
        for c, o in zip(chk, g["open"]):
            if o is not None:
                colours[c] = OPEN_MAP(float(np.clip(o, 0.0, 1.0)))
    nx.draw_networkx_nodes(
        graph, pos, nodelist=list(range(len(types))), node_color=colours, edgecolors="#17202a", node_size=260, ax=ax
    )
    nx.draw_networkx_labels(graph, pos, labels=dict(enumerate(static["nodes"]["id"])), font_size=6, ax=ax)
    regime = static.get("regime")
    fig.suptitle(f"week {obs['week']}  |  regime {regime['name'] if regime else 'hidden'}", fontsize=9)
    canvas.draw()
    return np.asarray(canvas.buffer_rgba())[:, :, :3].copy()
