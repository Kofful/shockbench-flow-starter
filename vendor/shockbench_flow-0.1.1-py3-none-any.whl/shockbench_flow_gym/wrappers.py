"""RL-friendly wrappers of ``ShockBenchFlowEnv`` (the gymnasium adapter, design §9.1): actions, reward, scenarios, logs.

- ``CapacityFractionAction``: the action becomes a ``Box`` [0, 1] per action slot; the adapter receives
  ``flows = clip(a, 0, 1) * capacity * action_mask``, the capacity of a slot being the nominal weekly capacity u0 of
  its first edge (``Static.edges.u0`` at ``Static.action_slots.edge``, as the samples read it) and the mask the one of
  the observation the action answers. ``override_qty`` and ``release_mode`` are left to the adapter's defaults (zeros:
  the default release everywhere). All ones is "send the maximum" exactly, and no entry is ever dropped as invalid
  for a masked slot. The bounds are finite, so ``gymnasium.wrappers.RescaleAction`` maps them to [-1, 1].
- ``ScaleReward``: the reward (USD by default: r_t / 100 of (25)) divided by a per-instance scale, the anchor naive's
  mean weekly cost J^naive / T on the dev split (``REWARD_SCALE_USD``), so a week as costly as naive's average gives
  about -1. The adapter's own ``reward_scale`` must stay 1 (no double scaling).
- ``ScenarioPool``: N scenarios of the public generator (the instance's profile at rung ``gamma``) drawn once from an
  entropy of the participant's choosing, episodes ``first_episode .. first_episode + N - 1`` of that root (labelled as
  the registered environment labels the root, ``hosting.tasks.split_label``, so they are its episodes omega for omega),
  stored as omega ``.npz`` files in a disk cache and served on reset: ``reset(seed=s)`` repeats its scenario (the
  adapter draws the episode index from its seeded ``np_random``; the pool serves that index modulo N),
  ``options={"pool_index": i}`` serves scenario i. ``info["episode"]`` is the generator's episode index of the scenario
  served and ``info["pool_index"]`` its place in the pool. Drawing a `tiny` scenario takes most of a second; serving a
  cached one a few milliseconds. ``draw_scenarios`` fills the same cache without an environment (with joblib workers),
  e.g. once in the main process before vectorised workers each build their pool from it.
- ``EpisodeRecorder``: saves each finished episode (terminated or truncated; an episode left by a new ``reset`` is
  discarded) to ``<directory>/<prefix>-<count:05d>.npz``, read back by ``load_record``. The file format below is the
  one of every episode record: ``save_record`` writes an in-memory record in it (``shockbench_flow_gym.dashboard``'s
  ``record_episode``, which plays through this recorder), and the dashboard reads files through ``load_record``.
- ``SlimInfo``: keeps only the named keys of every ``info`` (default ``SLIM_INFO_KEYS``: the scenario's names and the
  week's integer cents). The adapter's info carries the §9.2 observation every week and Static at reset, some 11 kB
  and 60 kB pickled on `tiny`; a vectorised trainer over subprocesses (Stable-Baselines3's ``SubprocVecEnv``)
  pickles every info through a pipe, which made the pipe, not the environment, the bottleneck of a PPO run on the
  worker VM (about 440 environment weeks a second with 8 workers, most of the main process's time in ``pickle.loads``).

Stacking: the action and recorder wrappers read the adapter's Dict observation, so they go inside any observation
wrapper, e.g. ``RescaleAction(FlattenObservation(ScaleReward(CapacityFractionAction(EpisodeRecorder(env)))), -1, 1)``;
``ScenarioPool`` may wrap anything whose ``unwrapped`` is a ``ShockBenchFlowEnv`` (``gym.make("ShockBench/Tiny-v0")``
among them), and goes inside ``EpisodeRecorder`` when both are used, so that the recorded episode is the pool's
(``EpisodeRecorder(ScenarioPool(env, ...), ...)``).

The episode file (``sbf-episode/1``), arrays without pickles:

- ``obs.<key>``: every Dict observation of the episode stacked, shape (weeks + 1, ...), the reset's first;
- ``action.<key>``: the actions the recorder received, shape (weeks, ...); a Dict action has its missing keys filled
  with the adapter's defaults (zeros), any other action is stored as ``action.action``;
- ``reward`` (weeks,) as the wrapped env returned it, ``reward_cents`` (weeks,) the integer cents of (25) (the
  terminal salvage included in the last week's) and ``costs`` (weeks, 8) the cost components C_t in USD, in the order
  of ``meta['cost_components']``;
- ``meta``, ``static`` and ``events``: JSON text. ``meta`` holds the format, instance, regime, episode (the
  ``info["episode"]`` that names the scenario when the environment draws its scenarios by index, a callable omega
  source such as the registered environment's or a pool's, else null; and ``pool_index`` under a pool), the reset's
  seed, policy seed, T, weeks, terminated, truncated, J_cents (the minus sum
  of ``reward_cents``: J^pi of the episode when it terminated), salvage_cents, the observation and action keys and the
  cost component names; ``static`` is the reset's Static (the network's names and tables); ``events`` is the list of
  ``timeline.observed_events`` of the episode (what changed in the observed disruption signals, week by week);
- ``naive.<key>``: optional extra arrays (the dashboard's naive anchor on the same scenario: ``reward_cents``,
  ``costs``), read into ``record["naive"]``; a record may carry more ``meta`` keys (the dashboard's ``agent``,
  ``naive_J_cents``, ``naive_replications``).
"""

import hashlib
import json
import math
import os
import tempfile
from pathlib import Path

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from shockbench_flow.disruption.params import generator_id
from shockbench_flow.disruption.profiles import ANCHOR_GAMMA
from shockbench_flow.disruption.sampler import sample_omega
from shockbench_flow.evaluation.cache import CACHE_VAR, default_cache_dir
from shockbench_flow.hosting.tasks import generator_profiles, split_label
from shockbench_flow.information.flat import COST_COMPONENTS
from shockbench_flow.instance import load_instance
from shockbench_flow.instance.schema import Instance
from shockbench_flow.omega.container import load_omega, save_omega
from shockbench_flow.omega.seeds import check_entropy, check_episode
from shockbench_flow_agent.convert import agent_config
from shockbench_flow_gym.timeline import observed_events


# the anchor naive's mean weekly cost on the dev split's 20 episodes (J^naive / T averaged, USD per week), keyed by
# instance id. tiny: the README's episodes, docs/evidence/rl_reward_scale.txt,
# `SBF_N_JOBS=8 uv run python scripts/python/evidence/rl_reward_scale.py` (worker VM, Linux x86_64 AMD EPYC 7B12,
# idle; every J^naive equal to the hackathon evaluation's to the cent at the launch commit; on the M5 merge's code dev
# episode 3's differs, docs/results.md M5 "Merge into feat"). small and full, on the M5 merge's code:
# docs/evidence/rl_reward_scale_small.txt and rl_reward_scale_full.txt, the same script with the argument `small` or
# `full` (the same VM, both at once: load 1.0 at the start, 12.7 at most at the end)
REWARD_SCALE_USD: dict[str, float] = {
    "chokepoint-tiny": 102_605_053.22,
    "chokepoint-small": 67_024_547_307.78,
    "chokepoint-full": 89_880_564_005.63,
}

# generator profiles by instance kind (design §2.4, §4.2): the public tasks' (``hosting.tasks.TASKS``: tiny, and small
# and full since the M5 merge)
PROFILES = generator_profiles()

# the cache root, shared with shockbench_flow_agent.evaluate (``evaluation.cache.default_cache_dir``): $SBF_CACHE_DIR,
# else ~/.cache/shockbench-flow
CACHE_ENV = CACHE_VAR
RECORD_FORMAT = "sbf-episode/1"
DICT_ACTION_KEYS = ("flows", "override_qty", "release_mode")
SLIM_INFO_KEYS = ("episode", "pool_index", "policy_seed", "reward_cents", "salvage_cents", "dense_cents")


def _adapter(env: gym.Env, what: str):
    base = env.unwrapped
    if not hasattr(base, "layout") or not hasattr(base, "instance"):
        raise ValueError(f"{what} wraps a ShockBenchFlowEnv (env.unwrapped), got {type(base).__name__}")
    return base


def _dict_observation(env: gym.Env, what: str) -> None:
    space = env.observation_space
    if not isinstance(space, spaces.Dict) or "action_mask" not in space.spaces:
        raise ValueError(
            f"{what} reads the adapter's Dict observation (its 'action_mask'): put it inside any observation wrapper "
            f"(FlattenObservation, FilterObservation), got {type(space).__name__}"
        )


class CapacityFractionAction(gym.ActionWrapper):
    """A ``Box`` [0, 1] per action slot: flows = clip(a, 0, 1) * capacity * action_mask (module docstring)."""

    def __init__(self, env: gym.Env) -> None:
        """Wrap ``env``, whose observation is the adapter's Dict one.

        Raises:
            ValueError: if ``env`` is not a ``ShockBenchFlowEnv`` or its observation is not the Dict observation.

        """
        super().__init__(env)
        base = _adapter(env, "CapacityFractionAction")
        _dict_observation(env, "CapacityFractionAction")
        inst = base.instance
        # u0 of each slot's first edge (the slot's edge; lanes start there), never None: coupling edges have no slot
        self.capacity = np.array([inst.edges[e].u0 for e, _k, _lane in inst.action_slots], dtype=np.float64)
        self.action_space = spaces.Box(0.0, 1.0, (base.layout.n_slots,), np.float32)
        self._mask: np.ndarray | None = None

    def _keep_mask(self, obs: dict) -> None:
        self._mask = np.asarray(obs["action_mask"], dtype=np.float64)

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        self._keep_mask(obs)
        return obs, info

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(self.action(action))
        self._keep_mask(obs)
        return obs, reward, terminated, truncated, info

    def action(self, action) -> dict:
        """The adapter's Dict action of a fraction vector (the mask of the last observation)."""
        if self._mask is None:
            raise RuntimeError("call reset before step")
        frac = np.clip(np.asarray(action, dtype=np.float64).reshape(self.capacity.shape), 0.0, 1.0)
        return {"flows": frac * self.capacity * self._mask}


class ScaleReward(gym.RewardWrapper):
    """The reward divided by ``scale`` (default ``REWARD_SCALE_USD`` of the instance; module docstring)."""

    def __init__(self, env: gym.Env, scale: float | None = None) -> None:
        """Wrap ``env`` (a ``ShockBenchFlowEnv`` with ``reward_scale`` 1).

        Raises:
            ValueError: on a scale that is not a positive finite number, an instance whose scale is not measured
                (pass ``scale``), or an adapter whose own ``reward_scale`` is not 1.

        """
        super().__init__(env)
        base = _adapter(env, "ScaleReward")
        if base.reward_scale != 1.0:
            raise ValueError(f"the adapter already divides by reward_scale={base.reward_scale}: leave it at 1")
        if scale is None:
            iid = base.instance.instance_id
            if iid not in REWARD_SCALE_USD:
                raise ValueError(
                    f"the reward scale of {iid!r} is not measured: pass scale= (scripts/python/evidence/"
                    "rl_reward_scale.py measures it)"
                )
            scale = REWARD_SCALE_USD[iid]
        if isinstance(scale, bool) or not isinstance(scale, (int, float)) or not (math.isfinite(scale) and scale > 0):
            raise ValueError(f"scale must be a positive finite number, got {scale!r}")
        self.scale = float(scale)

    def reward(self, reward):
        return reward / self.scale


def scenario_dir(inst, params, entropy: int, split: str, cache_dir: str | Path | None = None) -> Path:
    """The cache directory of one pool's omegas: instance, generator id, split and the SHA-256 of the entropy."""
    root = default_cache_dir() if cache_dir is None else Path(cache_dir)
    e = hashlib.sha256(str(check_entropy(entropy)).encode()).hexdigest()[:16]
    return root / "scenarios" / f"{inst.instance_id}-g{generator_id(params, inst)[:16]}-{split}-e{e}"


def _draw(inst, params, entropy: int, n: int, split: str, path: Path) -> None:
    """Draw scenario n and write it to ``path`` atomically (a temporary file renamed), so readers never see half."""
    omega = sample_omega(inst, params, entropy, n, split)
    fd, tmp = tempfile.mkstemp(suffix=".npz", dir=path.parent)
    os.close(fd)
    try:
        save_omega(omega, tmp)
        os.replace(tmp, path)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def generator_params(inst: Instance, gamma: float = ANCHOR_GAMMA):
    """The public generator of ``inst``: its kind's profile (``PROFILES``) at rung ``gamma``.

    Raises:
        ValueError: on an instance kind without a generator profile.

    """
    if inst.kind not in PROFILES:
        raise ValueError(f"no generator profile for {inst.kind!r} instances (profiles: {sorted(PROFILES)})")
    return PROFILES[inst.kind](inst, gamma)


def draw_scenarios(
    instance: str | Path | Instance,
    n_scenarios: int,
    entropy: int,
    *,
    split: str | None = None,
    first_episode: int = 0,
    gamma: float = ANCHOR_GAMMA,
    cache_dir: str | Path | None = None,
    n_jobs: int = 1,
) -> list[Path]:
    """The omega files of episodes ``first_episode .. + n_scenarios - 1`` of ``entropy``, drawing the missing ones.

    Each is ``sample_omega(inst, params, entropy, n, split)`` of the instance's public generator at rung ``gamma``,
    saved under ``scenario_dir`` (``cache_dir`` None: ``default_cache_dir()``); ``n_jobs`` joblib workers draw the
    missing files (one: in this process). ``split`` is the omega's label, by default the registered environment's
    (``hosting.tasks.split_label``: ``dev`` for the public dev root, ``train`` for any other), so that episode n of a
    pool is episode n of ``gym.make("ShockBench/Tiny-v0", entropy=entropy)``, omega for omega.

    Raises:
        ValueError: on a count below 1, an entropy outside [0, 2**128), an episode range outside [0, 2**32), or an
            instance kind without a generator profile.

    """
    if isinstance(n_scenarios, bool) or not isinstance(n_scenarios, int) or n_scenarios < 1:
        raise ValueError(f"n_scenarios must be an integer >= 1, got {n_scenarios!r}")
    check_entropy(entropy)
    check_episode(first_episode)
    check_episode(first_episode + n_scenarios - 1)
    split = split_label(entropy) if split is None else split
    inst = instance if isinstance(instance, Instance) else load_instance(instance)
    params = generator_params(inst, gamma)
    directory = scenario_dir(inst, params, entropy, split, cache_dir)
    directory.mkdir(parents=True, exist_ok=True)
    episodes = range(first_episode, first_episode + n_scenarios)
    paths = [directory / f"{n}.npz" for n in episodes]
    missing = [(n, p) for n, p in zip(episodes, paths) if not p.exists()]
    if missing and n_jobs == 1:
        for n, p in missing:
            _draw(inst, params, entropy, n, split, p)
    elif missing:
        from joblib import Parallel, delayed

        Parallel(n_jobs=n_jobs)(delayed(_draw)(inst, params, entropy, n, split, p) for n, p in missing)
    return paths


class ScenarioPool(gym.Wrapper):
    """N pre-drawn scenarios of one entropy, from a disk cache, served on reset (module docstring)."""

    def __init__(
        self,
        env: gym.Env,
        n_scenarios: int,
        entropy: int,
        *,
        split: str | None = None,
        first_episode: int = 0,
        gamma: float = ANCHOR_GAMMA,
        cache_dir: str | Path | None = None,
        n_jobs: int = 1,
    ) -> None:
        """Draw the scenarios missing from the cache (``draw_scenarios``), then serve them on reset.

        Raises:
            ValueError: as ``draw_scenarios``, or if ``env.unwrapped`` is not a ``ShockBenchFlowEnv``.

        """
        super().__init__(env)
        base = _adapter(env, "ScenarioPool")
        self.paths = draw_scenarios(
            base.instance,
            n_scenarios,
            entropy,
            split=split,
            first_episode=first_episode,
            gamma=gamma,
            cache_dir=cache_dir,
            n_jobs=n_jobs,
        )
        self.entropy, self.split, self.gamma = entropy, split_label(entropy) if split is None else split, gamma
        self.episodes = list(range(first_episode, first_episode + n_scenarios))
        self._generator_id = generator_id(generator_params(base.instance, gamma), base.instance)
        self._forced: int | None = None
        self._index: int | None = None
        base.omega_source = self._serve

    def _serve(self, n: int):
        """The omega of pool index ``n`` mod N (or the forced index), checked against the generator it came from."""
        i = self._forced if self._forced is not None else n % len(self.paths)
        omega = load_omega(self.paths[i])
        drawn = (omega.generator_id, int(omega["meta_episode"]), str(omega["meta_split"]))
        if drawn != (self._generator_id, self.episodes[i], self.split):
            raise ValueError(
                f"{self.paths[i]}: holds (generator, episode, split) {drawn}, not "
                f"{(self._generator_id, self.episodes[i], self.split)}: a stale cache file (delete it)"
            )
        self._index = i
        return omega

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        """Reset on a pool scenario: the seed's, or ``options['pool_index']``'s; the other options pass through.

        Raises:
            ValueError: on a ``pool_index`` outside [0, N), or an ``episode`` option (the pool serves by
                ``pool_index``).
            RuntimeError: if the adapter's reset did not take its omega from the pool (``omega_source`` replaced).

        """
        opts = dict(options or {})
        forced = opts.pop("pool_index", None)
        if "episode" in opts:
            raise ValueError("a ScenarioPool serves its scenarios by options['pool_index'], not options['episode']")
        if forced is not None and not (isinstance(forced, (int, np.integer)) and 0 <= forced < len(self.paths)):
            raise ValueError(f"pool_index must be an integer in [0, {len(self.paths)}), got {forced!r}")
        self._forced, self._index = (None if forced is None else int(forced)), None
        try:
            obs, info = self.env.reset(seed=seed, options=opts or None)
        finally:
            self._forced = None
        if self._index is None:
            raise RuntimeError("the adapter's reset did not draw its omega from the pool (env.unwrapped.omega_source)")
        info["pool_index"] = self._index
        info["episode"] = self.episodes[self._index]
        return obs, info


def _json(x) -> str:
    return json.dumps(x, allow_nan=True, default=_json_default)


def _json_default(x):
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, np.floating):
        return float(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    raise TypeError(f"not JSON serialisable: {type(x).__name__}")


class EpisodeRecorder(gym.Wrapper):
    """Saves each finished episode as ``<directory>/<prefix>-<count:05d>.npz``; ``paths`` lists the files written."""

    def __init__(self, env: gym.Env, directory: str | Path, *, prefix: str = "episode", compress: bool = True) -> None:
        """Wrap ``env`` (the adapter's Dict observation); ``compress`` writes ``np.savez_compressed``.

        Raises:
            ValueError: if ``env`` is not a ``ShockBenchFlowEnv`` or its observation is not the Dict observation.

        """
        super().__init__(env)
        _adapter(env, "EpisodeRecorder")
        _dict_observation(env, "EpisodeRecorder: the Dict observation")
        self.directory, self.prefix, self.compress = Path(directory), prefix, compress
        self.paths: list[Path] = []
        self._ep: dict | None = None

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        obs, info = self.env.reset(seed=seed, options=options)
        base = self.env.unwrapped
        config = agent_config(info["static"], info["policy_seed"], base.layout, obs)
        self._ep = {
            "config": config,
            "obs": [obs],
            "actions": [],
            "reward": [],
            "cents": [],
            "costs": [],
            "events": observed_events(config, None, obs),
            "meta": {
                "format": RECORD_FORMAT,
                "instance": base.instance.instance_id,
                "regime": base.regime,
                # a fixed omega (not a callable source) is played whatever index the adapter drew: none names it
                "episode": info.get("episode") if callable(base.omega_source) else None,
                "pool_index": info.get("pool_index"),
                "seed": seed,
                "policy_seed": info["policy_seed"],
                "T": base.instance.T,
                "cost_components": list(COST_COMPONENTS),
            },
            "static": info["static"],
        }
        return obs, info

    def _action(self, action) -> dict[str, np.ndarray]:
        if not isinstance(action, dict):
            return {"action": np.array(action, copy=True)}
        space = self.env.action_space
        out = {}
        for key in DICT_ACTION_KEYS:
            value = action.get(key)
            sub = space[key] if isinstance(space, spaces.Dict) and key in space.spaces else None
            if value is None and sub is not None:
                value = np.zeros(sub.shape, dtype=sub.dtype)
            if value is not None:
                out[key] = np.array(value, copy=True)
        return out

    def step(self, action):
        if self._ep is None:
            raise RuntimeError("call reset before step")
        obs, reward, terminated, truncated, info = self.env.step(action)
        ep = self._ep
        ep["events"] += observed_events(ep["config"], ep["obs"][-1], obs)
        ep["obs"].append(obs)
        ep["actions"].append(self._action(action))
        ep["reward"].append(float(reward))
        ep["cents"].append(int(info["reward_cents"]))
        ep["costs"].append([info["cost_components"][k] for k in COST_COMPONENTS])
        if terminated or truncated:
            ep["meta"].update(
                terminated=bool(terminated),
                truncated=bool(truncated),
                salvage_cents=info.get("salvage_cents"),
            )
            self._write(ep)
            self._ep = None
        return obs, reward, terminated, truncated, info

    def _write(self, ep: dict) -> None:
        weeks = len(ep["reward"])
        meta = ep["meta"] | {
            "weeks": weeks,
            "J_cents": -sum(ep["cents"]),
            "obs_keys": list(ep["obs"][0]),
            "action_keys": list(ep["actions"][0]) if ep["actions"] else [],
        }
        record = {
            "meta": meta,
            "static": ep["static"],
            "events": ep["events"],
            "obs": {k: np.stack([o[k] for o in ep["obs"]]) for k in ep["obs"][0]},
            "action": {k: np.stack([a[k] for a in ep["actions"]]) for k in meta["action_keys"]},
            "reward": np.array(ep["reward"], dtype=np.float64),
            "reward_cents": np.array(ep["cents"], dtype=np.int64),
            "costs": np.array(ep["costs"], dtype=np.float64).reshape(weeks, len(COST_COMPONENTS)),
        }
        path = self.directory / f"{self.prefix}-{len(self.paths):05d}.npz"
        self.paths.append(save_record(record, path, compress=self.compress))


class SlimInfo(gym.Wrapper):
    """Keeps only the ``keys`` of every reset and step ``info`` (module docstring); nothing else changes."""

    def __init__(self, env: gym.Env, keys: tuple[str, ...] = SLIM_INFO_KEYS) -> None:
        super().__init__(env)
        self.keys = tuple(keys)

    def _slim(self, info: dict) -> dict:
        return {k: info[k] for k in self.keys if k in info}

    def reset(self, **kwargs):
        obs, info = self.env.reset(**kwargs)
        return obs, self._slim(info)

    def step(self, action):
        obs, reward, terminated, truncated, info = self.env.step(action)
        return obs, reward, terminated, truncated, self._slim(info)


def save_record(record: dict, path: str | Path, *, compress: bool = True) -> Path:
    """Write an episode record (``load_record``'s dict) as the episode file (module docstring), without pickles.

    The ``.npz`` suffix is added when missing; ``record["naive"]``, when present, becomes the ``naive.<key>`` arrays.

    Returns:
        The path written.

    Raises:
        ValueError: if ``record["meta"]`` is not of the ``sbf-episode/1`` format.

    """
    meta = record.get("meta")
    if not isinstance(meta, dict) or meta.get("format") != RECORD_FORMAT:
        raise ValueError(f"record: an episode record of format {RECORD_FORMAT!r} (EpisodeRecorder, load_record)")
    arrays = {f"obs.{k}": np.asarray(v) for k, v in record["obs"].items()}
    arrays |= {f"action.{k}": np.asarray(v) for k, v in record["action"].items()}
    arrays |= {k: np.asarray(record[k]) for k in ("reward", "reward_cents", "costs")}
    arrays |= {k: np.array(_json(record[k])) for k in ("meta", "static", "events")}
    arrays |= {f"naive.{k}": np.asarray(v) for k, v in (record.get("naive") or {}).items()}
    path = Path(path)
    path = path if path.suffix == ".npz" else path.with_name(path.name + ".npz")
    path.parent.mkdir(parents=True, exist_ok=True)
    (np.savez_compressed if compress else np.savez)(path, **arrays)
    return path


def load_record(path: str | Path) -> dict:
    """An episode file as a dict (module docstring for the fields), read without pickle.

    Keys ``meta``, ``static`` and ``events`` (the parsed JSON), ``obs`` and ``action`` (dicts of arrays by key),
    ``reward``, ``reward_cents`` and ``costs``, and ``naive`` (a dict of its arrays) when the file has ``naive.*``.

    Raises:
        ValueError: if the file is not of the ``sbf-episode/1`` format.

    """
    with np.load(Path(path), allow_pickle=False) as z:
        meta = json.loads(str(z["meta"])) if "meta" in z.files else {}
        if meta.get("format") != RECORD_FORMAT:
            raise ValueError(f"{path}: not an episode record of format {RECORD_FORMAT}")
        record = {
            "meta": meta,
            "static": json.loads(str(z["static"])),
            "events": json.loads(str(z["events"])),
            "obs": {k: z[f"obs.{k}"] for k in meta["obs_keys"]},
            "action": {k: z[f"action.{k}"] for k in meta["action_keys"]},
            "reward": z["reward"],
            "reward_cents": z["reward_cents"],
            "costs": z["costs"],
        }
        naive = {k[len("naive.") :]: z[k] for k in z.files if k.startswith("naive.")}
    return record | ({"naive": naive} if naive else {})
