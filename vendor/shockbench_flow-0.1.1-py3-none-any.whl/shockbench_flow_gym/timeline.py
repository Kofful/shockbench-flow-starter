"""What an agent can see change, week by week: the disruption signals of a stream of Dict observations.

A reading aid for exploring episodes (the hackathon starter guide, ``docs/hackathon/starter_guide.ipynb``), not part
of the environment or the scoring. ``observed_events(config, prev, obs)`` compares two consecutive Dict observations
(the adapter's, which ``act`` also receives) and lists what changed in the observed disruption state:

- ``chokepoint``: an open fraction ``graph_now.open`` changed;
- ``prohibited`` and ``lifted``: an (edge, commodity) entered or left ``graph_now.prohibited``;
- ``capacity``: an edge's capacity ``graph_now.u`` changed; ``tariff``: a tariff rate on (edge, commodity) changed;
  ``war_risk``: a chokepoint's war-risk class changed;
- ``fab``, ``osat``, ``grid`` and ``supply``: a restoration factor R (``graph_now.fab.R``, ``graph_now.osat.R``), a
  deliverable generation ``graph_now.grid.G_bar`` or a supply availability ``graph_now.supply.avail`` changed;
- ``message``, ``message_update`` and ``message_ended``: an announcement thread joined the live list ``messages.*``,
  changed (a proposal became a final notice, a stated week moved) or left it (it took effect or was withdrawn);
  ``pending``: an announced prohibition joined ``pending_prohibitions.*``;
- ``closure_end``: an announced end week of a closure appeared in ``closure_end.*``.

With ``prev`` None the events are the disruptions already present in ``obs``: chokepoints not fully open, prohibitions
in force, edges below their nominal capacity ``u0``, tariffs above zero, fabs or OSATs with a restoration factor below
1, live threads and pending prohibitions. Only observed values are compared (their ``.observed`` masks), so a
blackout week, a masked field and the final observation (week T + 1, whose graph is unobserved) add nothing.
``warning.score`` is a noisy score every week, not an event: plot it instead.

``episode_events(env)`` plays one episode of a ``ShockBenchFlowEnv`` with zero flows and returns every event of it.
The observed graph, the warnings and the messages are exogenous (drawn with the scenario before the episode starts;
the action moves only the agent's own state), so zero flows show the same signals as any agent would see.

Each event is a dict with ``week`` (the observation's week t; the state is the one at instant t - 1), ``signal`` (one
of the names above), ``subject`` (what it is about, by name), ``before`` and ``after`` (the values, None where not
applicable) and ``note`` (a short text; a message's names its thread id and stated effective week).
"""

from collections.abc import Mapping

import numpy as np

from shockbench_flow.instance.schema import WAR_RISK_CLASSES
from shockbench_flow.omega import codes
from shockbench_flow_agent.convert import agent_config


OBS = ".observed"
EPS = 1e-9  # changes below this are rounding, not a signal (a display threshold, not a model value)


def _event(week: int, signal: str, subject: str, before=None, after=None, note: str = "") -> dict:
    return {"week": week, "signal": signal, "subject": subject, "before": before, "after": after, "note": note}


def _num(x) -> float | int:
    return int(x) if isinstance(x, np.integer) else float(x)


def _changed(obs, prev, key: str) -> list[tuple[tuple[int, ...], float | int, float | int]]:
    """(position, before, after) of each entry of a densified block observed in both and different."""
    a, b = prev[key], obs[key]
    seen = (prev[key + OBS] == 1) & (obs[key + OBS] == 1)
    diff = seen & (np.abs(b.astype(float) - a.astype(float)) > EPS)
    return [(i, _num(a[i]), _num(b[i])) for i in zip(*np.nonzero(diff))]


def _names(config: Mapping) -> dict:
    st, lay = config["static"], config["layout"]
    return {
        "node": st["nodes"]["id"],
        "edge": st["edges"]["id"],
        "k": st["commodities"]["id"],
        "region": st["regions"],
        "chokepoint": [st["nodes"]["id"][c] for c in lay["chokepoints"]],
        "fab": [st["nodes"]["id"][n] for n in lay["fabs"]],
        "osat": [st["nodes"]["id"][n] for n in lay["osats"]],
        "grid": [st["nodes"]["id"][n] for n in lay["grids"]],
        "supply": [f"{st['nodes']['id'][n]} {st['commodities']['id'][k]}" for n, k in lay["supply_slots"]],
    }


def _target(names: dict, kind: int, target: int) -> str:
    what = codes.TARGET_KINDS[kind]
    table = {"chokepoint": names["node"], "edge": names["edge"], "node": names["node"], "region": names["region"]}
    return f"{what} {table[what][target]}"


def _threads(obs) -> dict[int, dict]:
    live = np.flatnonzero(obs["messages.msg_id" + OBS] == 1)
    keys = ("channel", "kind", "target_kind", "target", "k", "stated_effective_week")
    out = {}
    for i in live:
        row = {k: int(obs[f"messages.{k}"][i]) for k in keys}
        row["k_observed"] = bool(obs["messages.k" + OBS][i])
        row["stated_observed"] = bool(obs["messages.stated_effective_week" + OBS][i])
        out[int(obs["messages.msg_id"][i])] = row
    return out


def _thread_text(names: dict, m: dict) -> tuple[str, str]:
    what = f"{codes.CHANNELS[m['channel']]} {codes.MESSAGE_KINDS[m['kind']]}"
    subject = f"{what} on {_target(names, m['target_kind'], m['target'])}"
    if m["k_observed"]:
        subject += f" ({names['k'][m['k']]})"
    note = f"stated effective week {m['stated_effective_week']}" if m["stated_observed"] else "no stated effective week"
    return subject, note


def _pending(obs) -> dict[tuple[int, int], int]:
    live = np.flatnonzero(obs["pending_prohibitions.edge" + OBS] == 1)
    return {
        (int(obs["pending_prohibitions.edge"][i]), int(obs["pending_prohibitions.k"][i])): int(
            obs["pending_prohibitions.effective_week"][i]
        )
        for i in live
    }


def _closure_ends(obs) -> dict[int, int]:
    live = np.flatnonzero(obs["closure_end.end_week" + OBS] == 1)
    return {int(obs["closure_end.chokepoint"][i]): int(obs["closure_end.end_week"][i]) for i in live}


def _present(config: Mapping, obs: Mapping, names: dict, week: int) -> list[dict]:
    """The disruptions already present in ``obs`` (``prev`` None)."""
    st, out = config["static"], []
    for i, name in enumerate(names["chokepoint"]):
        if obs["graph_now.open" + OBS][i] and obs["graph_now.open"][i] < 1 - EPS:
            out.append(_event(week, "chokepoint", name, None, float(obs["graph_now.open"][i]), "not fully open"))
    seen = obs["graph_now.prohibited" + OBS] == 1
    for e, k in zip(*np.nonzero(seen & (obs["graph_now.prohibited"] == 1))):
        out.append(_event(week, "prohibited", f"{names['edge'][e]} {names['k'][k]}", None, 1, "in force"))
    for e, u0 in enumerate(st["edges"]["u0"]):
        if u0 is not None and obs["graph_now.u" + OBS][e] and obs["graph_now.u"][e] < u0 - EPS:
            out.append(_event(week, "capacity", names["edge"][e], float(u0), float(obs["graph_now.u"][e]), "below u0"))
    seen = obs["graph_now.tariff" + OBS] == 1
    for e, k in zip(*np.nonzero(seen & (obs["graph_now.tariff"] > EPS))):
        rate = float(obs["graph_now.tariff"][e, k])
        out.append(_event(week, "tariff", f"{names['edge'][e]} {names['k'][k]}", None, rate, "in force"))
    for signal, key, nominal in (("fab", "graph_now.fab.R", 1.0), ("osat", "graph_now.osat.R", 1.0)):
        for i, name in enumerate(names[signal]):
            if obs[key + OBS][i] and obs[key][i] < nominal - EPS:
                out.append(_event(week, signal, name, None, float(obs[key][i]), "restoration factor below 1"))
    out += _new_threads(names, {}, _threads(obs), week)
    out += [
        _event(week, "pending", f"{names['edge'][e]} {names['k'][k]}", None, w, f"takes effect in week {w}")
        for (e, k), w in _pending(obs).items()
    ]
    return out


def _new_threads(names: dict, before: dict, after: dict, week: int) -> list[dict]:
    out = []
    for mid, m in after.items():
        if mid not in before:
            subject, note = _thread_text(names, m)
            out.append(_event(week, "message", subject, None, None, f"thread {mid}, {note}"))
    return out


def observed_events(
    config: Mapping, prev: Mapping[str, np.ndarray] | None, obs: Mapping[str, np.ndarray]
) -> list[dict]:
    """The disruption signals that changed from ``prev`` to ``obs``, or those present in ``obs`` (module docstring).

    ``config`` is the agent config (``shockbench_flow_agent.convert.agent_config``: ``static`` and ``layout``), and
    ``prev`` and ``obs`` are consecutive Dict observations of one episode.
    """
    names, week = _names(config), int(obs["week"][0])
    if week > config["T"]:  # the final observation: nothing to decide, its graph is unobserved
        return []
    if prev is None:
        return _present(config, obs, names, week)
    out = [
        _event(week, "chokepoint", names["chokepoint"][i], a, b, "open fraction")
        for (i,), a, b in _changed(obs, prev, "graph_now.open")
    ]
    seen = (prev["graph_now.prohibited" + OBS] == 1) & (obs["graph_now.prohibited" + OBS] == 1)
    a, b = prev["graph_now.prohibited"] == 1, obs["graph_now.prohibited"] == 1
    out += [
        _event(week, "prohibited", f"{names['edge'][e]} {names['k'][k]}", 0, 1, "now in force")
        for e, k in zip(*np.nonzero(seen & b & ~a))
    ]
    out += [
        _event(week, "lifted", f"{names['edge'][e]} {names['k'][k]}", 1, 0, "no longer in force")
        for e, k in zip(*np.nonzero(seen & a & ~b))
    ]
    out += [
        _event(week, "capacity", names["edge"][e], x, y, "capacity u")
        for (e,), x, y in _changed(obs, prev, "graph_now.u")
    ]
    out += [
        _event(week, "tariff", f"{names['edge'][e]} {names['k'][k]}", x, y, "tariff rate")
        for (e, k), x, y in _changed(obs, prev, "graph_now.tariff")
    ]
    out += [
        _event(week, "war_risk", names["chokepoint"][i], WAR_RISK_CLASSES[x], WAR_RISK_CLASSES[y], "war-risk class")
        for (i,), x, y in _changed(obs, prev, "graph_now.war_risk")
    ]
    for signal, key, what in (
        ("fab", "graph_now.fab.R", "restoration factor R"),
        ("osat", "graph_now.osat.R", "restoration factor R"),
        ("grid", "graph_now.grid.G_bar", "deliverable generation"),
        ("supply", "graph_now.supply.avail", "supply available"),
    ):
        out += [_event(week, signal, names[signal][i], x, y, what) for (i,), x, y in _changed(obs, prev, key)]
    before, after = _threads(prev), _threads(obs)
    out += _new_threads(names, before, after, week)
    for mid, m in after.items():
        if mid in before and m != before[mid]:
            subject, note = _thread_text(names, m)
            out.append(_event(week, "message_update", subject, None, None, f"thread {mid}, {note}"))
    for mid, m in before.items():
        if mid not in after:
            subject, _note = _thread_text(names, m)
            out.append(_event(week, "message_ended", subject, None, None, f"thread {mid} took effect or was withdrawn"))
    was = _pending(prev)
    out += [
        _event(week, "pending", f"{names['edge'][e]} {names['k'][k]}", None, w, f"takes effect in week {w}")
        for (e, k), w in _pending(obs).items()
        if (e, k) not in was
    ]
    ends = _closure_ends(prev)
    out += [
        _event(week, "closure_end", names["node"][c], None, w, f"announced end week {w}")
        for c, w in _closure_ends(obs).items()
        if ends.get(c) != w
    ]
    return out


def episode_events(env, *, seed: int | None = None, options: dict | None = None) -> list[dict]:
    """Every event of one episode of ``env`` (a ``ShockBenchFlowEnv``), played with zero flows (module docstring).

    ``env`` may be wrapped (``gym.make("ShockBench/Tiny-v0")``) as long as it keeps the Dict observation and action.
    ``env.reset(seed=seed, options=options)`` starts the episode, so with a callable omega source the seed picks it
    (or ``options={"episode": n}``); with one omega the episode is that omega's whatever the seed.
    """
    obs, info = env.reset(seed=seed, options=options)
    layout = env.unwrapped.layout
    config = agent_config(info["static"], info["policy_seed"], layout, obs)
    events, prev, done = observed_events(config, None, obs), obs, False
    zero = {"flows": np.zeros(layout.n_slots)}
    while not done:
        obs, _reward, done, _truncated, _info = env.step(zero)
        events += observed_events(config, prev, obs)
        prev = obs
    return events
