"""``gym.make("ShockBench/Tiny-v0")``: one registered environment per public task (``hosting.tasks.TASKS``).

``import shockbench_flow_gym`` calls ``register_envs``, which registers ``Task.env_id`` for every task (`tiny`, and
`small` and `full` since the M5 merge added them to ``TASKS``: ``ShockBench/Small-v0``, ``ShockBench/Full-v0``). The
entry point is ``make_env``: a ``ShockBenchFlowEnv`` on the task's instance whose scenario source is the task's public
generator (``tasks.scenario``) under ``entropy``, the dev split's public root by default (then episode n is dev episode
n of the local evaluation, omega for omega) or a participant's own training root. Each ``reset(seed=s)`` draws an
episode index n from the seeded ``np_random`` (``ShockBenchFlowEnv.reset``), so a seed repeats its scenario, and
``info["episode"]`` is n: with the environment's ``entropy`` it names the scenario, which
``hosting.tasks.scenario(task, n, entropy=...)`` draws again. The regime defaults to ``standard``, the scored one
(``ShockBenchFlowEnv``'s own default is prediction-free).

The environment checker of ``gym.make`` stays on (gymnasium's default): it warns once that the float boxes are
unbounded (quantities are), and that ``flows`` is a Box on [0, inf); ``shockbench_flow_gym.wrappers`` gives the
bounded action learners want.
"""

import functools

import gymnasium as gym

from shockbench_flow.hosting.split import DEV_ENTROPY
from shockbench_flow.hosting.tasks import TASKS, scenario, split_label, task_generator
from shockbench_flow_gym.env import ShockBenchFlowEnv


ENTRY_POINT = "shockbench_flow_gym.registration:make_env"


def make_env(
    task: str = "tiny",
    regime: str = "standard",
    dense_reward: bool = False,
    render_mode: str | None = None,
    *,
    entropy: int = DEV_ENTROPY,
    gamma: float | None = None,
    **kwargs,
) -> ShockBenchFlowEnv:
    """A ``ShockBenchFlowEnv`` of a public task under its public generator (module docstring).

    Args:
        task: a task of ``hosting.tasks.TASKS`` (the registered id fixes it).
        regime: the information regime (``standard``, the scored one).
        dense_reward: §3.6's potential-shaped reward instead of the weekly cost.
        render_mode: None or ``rgb_array``.
        entropy: the scenarios' root: the dev split's public root (default) or any integer in [0, 2**128) of one's
            own (labelled ``train``).
        gamma: the policy-block rung (§2.6), default the task's (the anchor).
        **kwargs: passed to ``ShockBenchFlowEnv`` (``reward_scale``, ``policy_seed``, ``maxima``, ``fallback``).

    Raises:
        ValueError: on an unknown task, or as ``ShockBenchFlowEnv`` and the profile.

    """
    inst, _params = task_generator(task, gamma)
    source = functools.partial(scenario, task, entropy=entropy, gamma=gamma)
    env = ShockBenchFlowEnv(
        inst, omega_source=source, regime=regime, dense_reward=dense_reward, render_mode=render_mode, **kwargs
    )
    env.task, env.entropy, env.split = task, entropy, split_label(entropy)
    return env


make_env.metadata = ShockBenchFlowEnv.metadata  # read by gym.make to check render_mode


def register_envs() -> list[str]:
    """Register ``ShockBench/<Name>-v0`` for every task not registered yet; the ids of every task."""
    for task in TASKS.values():
        if task.env_id not in gym.registry:
            gym.register(id=task.env_id, entry_point=ENTRY_POINT, kwargs={"task": task.name})
    return [task.env_id for task in TASKS.values()]
