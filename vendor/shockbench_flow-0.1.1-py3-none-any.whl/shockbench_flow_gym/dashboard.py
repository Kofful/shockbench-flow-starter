"""Dashboards of the gymnasium adapter: the network map, one episode's multi-panel figure and its week-by-week GIF.

A reading aid for the hackathon (the README's images, ``examples/generate_dashboard.py``), not part of the environment
or the scoring. matplotlib ``Figure`` objects bound to the Agg canvas, never a ``pyplot`` figure (networkx's drawing
imports the module but is always handed an axes), so every figure builds without a display or a GUI backend and leaves
no global state (as ``shockbench_flow_gym.render``); the GIF is written by Pillow, no ffmpeg.

- ``plot_network(instance, detailed, ax)``: the instance as a graph, nodes by kind (colour, marker and column), edges by
  mode (line style); ``detailed=True`` labels each edge with its nominal capacity ``u0``, lead time ``tau0`` and unit
  freight ``c0`` (USD per unit).
- ``record_episode(env, agent, seed=, options=, naive_replications=)``: plays one episode of a ``ShockBenchFlowEnv``
  (``gym.make("ShockBench/Tiny-v0")``, or any wrapper that keeps its Dict observation and action) through
  ``wrappers.EpisodeRecorder`` and returns its record (below); with ``naive_replications`` the naive anchor also plays
  the same scenario (prediction-free, the env's policy seed, F_Q from that many replications of the generator that
  drew the scenario, as the scorer's anchor with ``fq_replications`` of them), its F_Q read from and kept in the local
  evaluation's disk cache (``evaluation.cache.fq_quantiles``; ``shockbench_flow_agent.evaluate`` shares it).
- ``episode_dashboard(record, path)``: the map at one week (default the week the chokepoint is least open) with each
  edge's observed state (``edge_states_flat``: blocked, that is closed for every commodity it carries or at capacity 0,
  reduced, open or unobserved) and each chokepoint's open fraction; the open fractions and the warning scores over
  the weeks; the stock of every stock slot over the weeks as a heatmap; the units shipped per week by commodity; the
  weekly cost by component and the cumulative cost against naive's on the same scenario; and a text strip of the
  timeline events (``shockbench_flow_gym.timeline``).
- ``episode_animation(record, path)``: a GIF with one frame per week 1..T (the map, the open fraction and the
  cumulative cost so far).

The episode file is the ``sbf-episode/1`` format of ``shockbench_flow_gym.wrappers.EpisodeRecorder``, written by
``wrappers.save_record`` and read by ``wrappers.load_record`` (this module's ``save_record`` and ``load_record`` are
those two), arrays without pickles: ``obs.<key>`` (the Dict observations of weeks 1..T+1 stacked, T+1 rows),
``action.<key>`` (T rows, a Dict action's missing keys filled with the adapter's zeros), ``reward`` (the env's),
``reward_cents`` (r_t of (25), ``info['reward_cents']`` whatever the reward form, the terminal credit in week T's),
``costs`` (T x 8 USD, ``info['cost_components']`` in the order of ``meta['cost_components']``), and ``meta``, ``static``
and ``events`` as JSON text: ``meta`` the format, instance, regime, episode (the env's ``info['episode']`` when it draws
scenarios by index, a callable omega source such as the registered environment's, else null;
``record_episode(episode=)`` names it otherwise), pool_index, the reset's seed, policy seed, T, weeks, terminated,
truncated, J_cents (the minus sum of ``reward_cents``), salvage_cents (S^¢_T of (24)), the observation and action keys
and the cost component names, and here also ``agent`` (a name) and, with naive, ``naive_J_cents`` and
``naive_replications``; ``static`` the reset's Static; ``events`` the ``timeline.observed_events`` of the episode.
Naive's weekly ``naive.reward_cents`` and ``naive.costs`` are extra arrays (``load_record`` reads them into
``record["naive"]``). In memory, ``record_episode`` gives the record as ``load_record`` reads the file: ``meta``,
``static``, ``events`` parsed, ``obs`` and ``action`` dicts of arrays by key, ``reward``, ``reward_cents``, ``costs``,
and ``naive`` when present.

Colours: the node kinds, commodities and cost components take the fixed categorical order of the reference palette
(one colour per entity, the same in every panel); edge and chokepoint states take the status colours (closed critical,
reduced serious; a chokepoint good when fully open, warning above half open, serious below, critical when closed),
always with a legend or a label. Display choices, not model values.
"""

import io
import math
import tempfile
from collections.abc import Callable, Mapping
from functools import wraps
from pathlib import Path

import matplotlib.style
import networkx as nx
import numpy as np
from matplotlib.backends.backend_agg import FigureCanvasAgg  # the Agg canvas, bound to its own Figure (no pyplot)
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.figure import Figure
from matplotlib.lines import Line2D
from matplotlib.ticker import FuncFormatter, MaxNLocator

from shockbench_flow.disruption.params import RUNGS, generator_id
from shockbench_flow.dynamics.env import rollout
from shockbench_flow.dynamics.state import COST_COMPONENTS
from shockbench_flow.evaluation.cache import default_cache_dir, fq_quantiles
from shockbench_flow.information.flat import FlatLayout
from shockbench_flow.instance import load_instance
from shockbench_flow.instance.schema import NODE_TYPES, Instance
from shockbench_flow.omega.container import Omega, load_omega
from shockbench_flow.policies.naive_fq import anchor_policy, fallback_spec
from shockbench_flow_agent.convert import agent_config, layout_tables
from shockbench_flow_gym.wrappers import (
    PROFILES,
    RECORD_FORMAT,
    EpisodeRecorder,
    ScenarioPool,
    generator_params,
    load_record,
    save_record,
)


__all__ = [  # the record's writer and reader are the recorder's (``wrappers``), re-exported here
    "PROFILES",
    "RECORD_FORMAT",
    "edge_states_flat",
    "episode_animation",
    "episode_dashboard",
    "load_record",
    "naive_run",
    "plot_network",
    "positions",
    "record_episode",
    "save_record",
    "scenario_params",
    "shipped_units",
    "timeline_lines",
]

ANCHOR_REGIME = "prediction_free"  # naive plays prediction-free whatever the agent plays (Q10), as the scorer's anchor
EPS = 1e-9  # an open fraction within this of 1 is fully open (a display threshold, not a model value)

# the reference palette of the dataviz method (light mode): ink, chrome, categorical order, status and a blue ramp
INK, INK_2, MUTED, GRID, AXIS, SURFACE = "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7", "#fcfcfb"
SERIES = ("#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#4a3aa7", "#e34948")
GOOD, WARNING, SERIOUS, CRITICAL = "#0ca30c", "#fab219", "#ec835a", "#d03b3b"
BLUES = ("#cde2fb", "#9ec5f4", "#6da7ec", "#3987e5", "#256abf", "#184f95", "#0d366b")
STOCK_MAP = LinearSegmentedColormap.from_list("stock", BLUES)
# node kind -> (colour, marker): a fixed slot per kind, the same in every figure
NODE_STYLE = {
    "source": (SERIES[0], "o"),
    "terminal": (SERIES[7], "v"),
    "grid": (SERIES[3], "p"),
    "chokepoint": (SERIES[6], "D"),
    "material": (SERIES[4], "h"),
    "fab": (SERIES[2], "s"),
    "osat": (SERIES[5], "^"),
    "sink": (SERIES[1], "8"),
}
MODE_STYLE = {"sea": "-", "air": (0, (4, 2)), "pipeline": (0, (8, 2, 2, 2)), "grid": (0, (1, 2))}
EDGE_STATE_STYLE = {  # state -> (colour, width)
    "open": (AXIS, 1.1),
    "reduced": (SERIOUS, 2.0),
    "closed": (CRITICAL, 2.4),
    "unobserved": (GRID, 0.9),
}
# node columns left to right (types absent from the instance leave no gap); chokepoints sit on a row above them
COLUMNS = (("source",), ("terminal",), ("grid", "material"), ("fab",), ("osat",), ("sink",))
NODE_SIZE = 300  # points^2 of every node marker (the arrows shrink by it)
LEGEND_ROOM = 1.5  # data units kept right of the nodes for the map's legend
MAX_TIMELINE_WEEKS = 18  # weeks the text strip lists (the most eventful ones, in week order)
TIMELINE_ORDER = (  # the order signals are named within a week of the strip
    "chokepoint",
    "closure_end",
    "prohibited",
    "lifted",
    "pending",
    "war_risk",
    "message",
    "capacity",
    "tariff",
    "fab",
    "osat",
    "grid",
    "supply",
    "message_update",
    "message_ended",
)
# the house style every figure is built under, over matplotlib's defaults (never the caller's matplotlibrc, so a figure
# looks the same on every machine): DejaVu Sans, which matplotlib ships, named directly so a figure drawn later outside
# the style keeps it; mathtext stays on for the log-scale ticks, so every "$" of a label is escaped ("\\$")
HOUSE_STYLE = {
    "font.family": "DejaVu Sans",
    "font.weight": "normal",
    "font.size": 10.0,
    "text.color": INK,
    "axes.titleweight": "normal",
    "figure.facecolor": SURFACE,
    "savefig.facecolor": SURFACE,
}
SALIENT = {"chokepoint", "closure_end", "prohibited", "lifted", "pending", "war_risk", "message"}


def _house_style(fn: Callable) -> Callable:
    """Build (and draw once) the figure under ``HOUSE_STYLE`` over matplotlib's defaults, whatever the caller's rc."""

    @wraps(fn)
    def styled(*args, **kwargs):
        with matplotlib.style.context(["default", HOUSE_STYLE]):
            out = fn(*args, **kwargs)
            if isinstance(out, Figure):
                out.canvas.draw()  # ticks and legends resolve their fonts now, under the style
            return out

    return styled


# ----------------------------------------------------------------------------------------------------------------------
# the record


def _actor(agent, config: dict, n_slots: int) -> Callable[[dict], dict]:
    """The ``act`` of ``agent``: an Agent class or factory of ``config``, an object with ``act``, or None (zeros)."""
    if agent is None:
        return lambda obs: {"flows": np.zeros(n_slots)}
    if hasattr(agent, "act") and not isinstance(agent, type):
        return agent.act
    made = agent(config)
    if not hasattr(made, "act"):
        raise TypeError(f"agent: {agent!r}(config) returned {type(made).__name__}, which has no act(observation)")
    return made.act


def _agent_name(agent) -> str:
    if agent is None:
        return "zero flows"
    return getattr(agent, "__name__", None) or type(agent).__name__


def _wrapper(env, cls: type):
    """The first wrapper of ``env``'s chain that is a ``cls``, or None."""
    while env is not None and not isinstance(env, cls):
        env = getattr(env, "env", None)
    return env


def _episode_omega(env, info: dict) -> Omega:
    """The omega ``env`` played last: its pool's file, else its source at ``info['episode']``; checked by hash."""
    u, pool = env.unwrapped, _wrapper(env, ScenarioPool)
    if pool is not None and info.get("pool_index") is not None:
        omega = pool.paths[info["pool_index"]]
    else:
        src = u.omega_source
        omega = src(info["episode"]) if callable(src) else src
    omega = omega if isinstance(omega, Omega) else load_omega(omega)
    if omega.hash != u.core.trajectory.omega_hash:
        raise ValueError("the omega source did not give back the scenario the environment played (hash differs)")
    return omega


def scenario_params(inst: Instance, omega: Omega):
    """The generator params that drew ``omega``: the instance kind's profile at the rung whose ``generator_id`` matches.

    The profile is the public task's (``wrappers.generator_params``, from ``hosting.tasks.TASKS``).

    Raises:
        ValueError: when no profile of ``PROFILES`` at any rung of ``RUNGS`` has the omega's ``generator_id``.

    """
    for gamma in RUNGS if inst.kind in PROFILES else ():
        params = generator_params(inst, gamma)
        if generator_id(params, inst) == omega.generator_id:
            return params
    raise ValueError(
        f"no generator profile of instance kind {inst.kind!r} drew this scenario (profiles: {sorted(PROFILES)}); "
        "naive's F_Q needs the generator's params"
    )


def naive_run(
    inst: Instance,
    omega: Omega,
    policy_seed: int,
    replications: int,
    n_jobs: int = 1,
    cache_dir: str | Path | bool | None = None,
) -> dict:
    """Naive, the anchor of (55), on ``omega``: ``{"reward_cents", "costs", "J_cents"}`` (module docstring).

    ``cache_dir``: where naive's F_Q is kept (``evaluation.cache.fq_quantiles``): None the local evaluation's
    (``default_cache_dir()``: ``SBF_CACHE_DIR``, else ``~/.cache/shockbench-flow``), False none (this process only).
    """
    params = scenario_params(inst, omega)
    if cache_dir is not False:  # the quantiles land in naive_fq's process cache, where anchor_policy takes them
        fq_quantiles(
            inst, params, replications, n_jobs=n_jobs, cache_dir=default_cache_dir() if cache_dir is None else cache_dir
        )
    anchor = anchor_policy(inst, params, replications, n_jobs)
    fallback = fallback_spec(inst, params, replications, n_jobs)
    traj = rollout(inst, anchor, omega, ANCHOR_REGIME, policy_seed, fallback=fallback)
    return {
        "reward_cents": np.array(traj.rewards_cents(), dtype=np.int64),
        "costs": np.array([[r.costs.as_dict()[c] for c in COST_COMPONENTS] for r in traj.records]),
        "J_cents": np.int64(traj.J_cents),
    }


def record_episode(
    env,
    agent=None,
    *,
    seed: int | None = None,
    options: dict | None = None,
    naive_replications: int | None = None,
    n_jobs: int = 1,
    episode: int | None = None,
    cache_dir: str | Path | bool | None = None,
) -> dict:
    """Play one episode of ``env`` with ``agent`` and return its record (module docstring), as ``load_record`` reads.

    ``env`` is a ``ShockBenchFlowEnv`` or a wrapper of one that keeps its Dict observation and action
    (``gym.make("ShockBench/Tiny-v0")``); the episode is played through ``wrappers.EpisodeRecorder``, so the record is
    its file's. ``agent`` is an Agent class or a factory of the agent config, an object with ``act(observation)``, or
    None (zero flows). ``env.reset(seed=seed, options=options)`` starts the episode (``options={"episode": n}`` plays
    episode n of the registered environment). ``naive_replications`` (an integer >= 1) adds naive on the same scenario
    (``naive_run``; ``n_jobs`` spreads its F_Q replications, ``cache_dir`` keeps them). ``episode`` names the scenario
    in the record and the figures when the env does not (a fixed omega); by default ``info['episode']`` when the env
    draws its scenarios by index, else None.
    """
    u = env.unwrapped
    with tempfile.TemporaryDirectory(prefix="sbf-record-") as tmp:
        recorder = EpisodeRecorder(env, tmp, compress=False)
        obs, info = recorder.reset(seed=seed, options=options)
        act = _actor(agent, agent_config(info["static"], info["policy_seed"], u.layout, obs), u.layout.n_slots)
        done = False
        while not done:
            obs, _reward, terminated, truncated, _info = recorder.step(act(obs))
            done = terminated or truncated
        record = load_record(recorder.paths[-1])
    meta = record["meta"] | {"agent": _agent_name(agent)}
    if episode is not None:
        meta["episode"] = int(episode)
    if naive_replications is not None:
        omega = _episode_omega(env, info)
        naive = naive_run(u.instance, omega, info["policy_seed"], naive_replications, n_jobs, cache_dir)
        meta |= {"naive_J_cents": int(naive.pop("J_cents")), "naive_replications": int(naive_replications)}
        record["naive"] = naive
    return record | {"meta": meta}


def _parse(record) -> dict:
    """A record (``record_episode``, ``load_record``) or the path of an episode file, checked for its format."""
    if isinstance(record, (str, Path)):
        return load_record(record)
    meta = record.get("meta") if isinstance(record, Mapping) else None
    if not isinstance(meta, Mapping) or meta.get("format") != RECORD_FORMAT:
        raise ValueError(
            f"record: an episode record of format {RECORD_FORMAT!r} (record_episode, load_record) or its path"
        )
    return dict(record)


def _view(record) -> tuple[dict, dict]:
    """(rec, config) of a record for the panels: ``rec`` flat by key, ``config`` Static, the layout tables and T.

    The layout tables are ``shockbench_flow_agent.convert.layout_tables`` of the flat layout of the record's Static.
    """
    ep = _parse(record)
    meta, static = ep["meta"], ep["static"]
    config = {"static": static, "layout": layout_tables(FlatLayout.from_static(static)), "T": int(meta["T"])}
    rec = {f"obs/{k}": v for k, v in ep["obs"].items()}
    rec |= {
        "reward_cents": np.asarray(ep["reward_cents"]),
        "cost": np.asarray(ep["costs"], dtype=np.float64),
        "cost_components": list(meta["cost_components"]),
        "agent": meta.get("agent") or "agent",
        "instance": meta["instance"],
        "regime": meta["regime"],
        "episode": meta.get("episode"),
        "J_cents": int(meta["J_cents"]),
        "events": ep["events"],
    }
    if ep.get("naive"):
        rec["naive/reward_cents"] = np.asarray(ep["naive"]["reward_cents"])
        rec["naive/J_cents"] = int(meta.get("naive_J_cents", -int(np.sum(ep["naive"]["reward_cents"]))))
    return rec, config


def _week(rec: Mapping, t: int) -> dict[str, np.ndarray]:
    """The Dict observation of week ``t`` (1..T+1) of a record."""
    return {k[4:]: v[t - 1] for k, v in rec.items() if k.startswith("obs/")}


def _seen(rec: Mapping, key: str) -> np.ndarray:
    """``obs/<key>`` over weeks 1..T+1 as floats, NaN where unobserved."""
    v = rec[f"obs/{key}"].astype(np.float64)
    return np.where(rec[f"obs/{key}.observed"] == 1, v, np.nan)


def shipped_units(record) -> np.ndarray:
    """(T, action slots): the units each slot's request executed in week t, from week t + 1's ``last_week.clip``."""
    return _shipped(_parse(record)["obs"])


def _shipped(obs: Mapping[str, np.ndarray]) -> np.ndarray:
    executed = obs["last_week.clip.executed"][1:]
    return np.where(obs["last_week.clip.executed.observed"][1:] == 1, executed, 0.0)


def edge_states_flat(static: Mapping, arrays: Mapping[str, np.ndarray]) -> list[str]:
    """Each edge's state (``EDGE_STATE_STYLE`` keys) in one Dict observation, as ``render.edge_states`` reads it.

    Closed: prohibited (observed) for every commodity it carries, or an observed capacity of 0; unobserved: its cost or
    lead time masked, or its capacity masked where it has a nominal one (a coupling edge has none); reduced: an
    observed capacity below ``u0``; else open.
    """
    u, u_seen = arrays["graph_now.u"], arrays["graph_now.u.observed"] == 1
    c_seen, tau_seen = arrays["graph_now.c.observed"] == 1, arrays["graph_now.tau.observed"] == 1
    banned = (arrays["graph_now.prohibited"] == 1) & (arrays["graph_now.prohibited.observed"] == 1)
    out = []
    for e, (K, u0) in enumerate(zip(static["edges"]["K"], static["edges"]["u0"])):
        if K and all(banned[e, k] for k in K):
            out.append("closed")
        elif not c_seen[e] or not tau_seen[e] or (u0 is not None and not u_seen[e]):
            out.append("unobserved")
        elif u_seen[e] and u[e] == 0:
            out.append("closed")
        elif u_seen[e] and u0 is not None and u[e] < u0:
            out.append("reduced")
        else:
            out.append("open")
    return out


# ----------------------------------------------------------------------------------------------------------------------
# the map


def _tables(instance: Instance) -> dict:
    """The Static-shaped node and edge tables of an instance (``nodes``: id, type; ``edges``: Static's columns)."""
    edges = instance.edges
    return {
        "instance_id": instance.instance_id,
        "T": instance.T,
        "nodes": {"id": [n.id for n in instance.nodes], "type": [n.type for n in instance.nodes]},
        "edges": {
            "id": [e.id for e in edges],
            "tail": [e.tail for e in edges],
            "head": [e.head for e in edges],
            "mode": [e.mode for e in edges],
            "tau0": [e.tau for e in edges],
            "c0": [e.c0 for e in edges],
            "u0": [e.u0 for e in edges],
            "K": [list(e.K) for e in edges],
        },
    }


def positions(types: list[str]) -> dict[int, tuple[float, float]]:
    """Node positions: columns by kind (``COLUMNS``), centred; chokepoints on a row above, spread over the middle."""
    cols = [[i for t in group for i, ty in enumerate(types) if ty == t] for group in COLUMNS]
    cols = [c for c in cols if c]
    height = max((len(c) for c in cols), default=1)
    pos = {i: (float(x), (len(col) - 1) / 2 - r) for x, col in enumerate(cols) for r, i in enumerate(col)}
    chk = [i for i, t in enumerate(types) if t == "chokepoint"]
    mid = (len(cols) - 1) / 2
    xs = np.linspace(max(mid - len(chk) / 2, 0.5), min(mid + len(chk) / 2, len(cols) - 1.5), len(chk))
    for x, i in zip(xs if len(chk) > 1 else [mid], chk):
        pos[i] = (float(x), (height - 1) / 2 + 1.1)
    return pos


def _fmt(x: float | None) -> str:
    if x is None:
        return "–"
    return f"{x:,.0f}" if abs(x) >= 100 else f"{x:.3g}"


def _open_colour(o: float) -> str:
    if not np.isfinite(o):
        return SURFACE
    if o >= 1 - EPS:
        return GOOD
    if o <= EPS:
        return CRITICAL
    return WARNING if o >= 0.5 else SERIOUS


def _draw_map(
    ax,
    tables: Mapping,
    *,
    states: list[str] | None = None,
    open_frac: Mapping[int, float] | None = None,
    detailed: bool = False,
    legend: str | None = "kinds",
    font: float = 7.0,
) -> None:
    """Draw the network on ``ax``: edges by mode (and state), nodes by kind (chokepoints by their open fraction).

    ``states`` colours each edge by its state (``EDGE_STATE_STYLE``); ``open_frac`` (chokepoint node -> fraction, NaN
    unobserved) fills each chokepoint by its status and adds its open fraction under its name.
    """
    types, edges = list(tables["nodes"]["type"]), tables["edges"]
    pos = positions(types)
    graph = nx.MultiDiGraph()
    graph.add_nodes_from(range(len(types)))
    seen: dict[tuple[int, int], int] = {}
    for e, (a, b) in enumerate(zip(edges["tail"], edges["head"])):
        rank = seen.get((a, b), 0)  # parallel edges bend apart, in edge order
        seen[(a, b)] = rank + 1
        graph.add_edge(a, b, key=e)
        colour, width = EDGE_STATE_STYLE[states[e]] if states else (MUTED, 1.0)
        style = f"arc3,rad={0.08 + 0.2 * rank}"
        nx.draw_networkx_edges(
            graph,
            pos,
            edgelist=[(a, b, e)],
            ax=ax,
            edge_color=colour,
            width=width,
            style=MODE_STYLE.get(edges["mode"][e], "-"),
            arrows=True,
            arrowsize=7,
            connectionstyle=style,
            node_size=NODE_SIZE,
        )
        if detailed:
            u0 = edges["u0"][e]
            label = f"u {_fmt(u0)} · τ {edges['tau0'][e]} · \\${_fmt(edges['c0'][e])}"
            nx.draw_networkx_edge_labels(
                graph,
                pos,
                edge_labels={(a, b, e): label},
                ax=ax,
                font_size=font - 2.2,
                font_color=INK_2,
                rotate=False,
                connectionstyle=style,
                node_size=NODE_SIZE,
                bbox={"boxstyle": "round,pad=0.15", "fc": SURFACE, "ec": "none", "alpha": 0.85},
            )
    for kind in NODE_TYPES:
        nodes = [i for i, t in enumerate(types) if t == kind]
        if not nodes:
            continue
        colour, marker = NODE_STYLE[kind]
        fill = [colour] * len(nodes)
        if kind == "chokepoint" and open_frac is not None:
            fill = [_open_colour(open_frac.get(i, np.nan)) for i in nodes]
        nx.draw_networkx_nodes(
            graph,
            pos,
            nodelist=nodes,
            node_color=fill,
            node_shape=marker,
            node_size=NODE_SIZE,
            edgecolors=INK,
            linewidths=0.8,
            ax=ax,
        )
    for i, name in enumerate(tables["nodes"]["id"]):
        x, y = pos[i]
        text = name
        if open_frac is not None and i in open_frac:
            o = open_frac[i]
            text += "\nopen –" if not np.isfinite(o) else f"\nopen {o:.0%}"
        above = types[i] == "chokepoint"
        ax.text(
            x + (0.14 if above else 0.0),
            y + (0.1 if above else -0.2),
            text,
            ha="left" if above else "center",
            va="bottom" if above else "top",
            fontsize=font,
            color=INK_2,
            linespacing=1.1,
        )
    xs, ys = zip(*pos.values())
    ax.set_xlim(min(xs) - 0.45, max(xs) + 0.45 + (LEGEND_ROOM if legend else 0.0))
    ax.set_ylim(min(ys) - 0.75, max(ys) + 0.55)
    ax.set_axis_off()
    if legend:
        _map_legend(ax, types, edges, legend, font)


def _map_legend(ax, types: list[str], edges: Mapping, which: str, font: float) -> None:
    handles, labels = [], []
    if which == "kinds":
        for kind in NODE_TYPES:
            if kind in types:
                colour, marker = NODE_STYLE[kind]
                handles.append(Line2D([], [], ls="", marker=marker, mfc=colour, mec=INK, ms=7, mew=0.8))
                labels.append(kind)
    if which == "kinds":
        for mode, style in MODE_STYLE.items():
            if mode in edges["mode"]:
                handles.append(Line2D([], [], color=MUTED, ls=style, lw=1.2))
                labels.append(f"{mode} edge")
    if which == "states":
        for state, (colour, width) in EDGE_STATE_STYLE.items():
            handles.append(Line2D([], [], color=colour, lw=max(width, 1.2)))
            labels.append(f"{state} edge")
        for text, colour in (
            ("fully open", GOOD),
            ("> half open", WARNING),
            ("< half open", SERIOUS),
            ("closed", CRITICAL),
        ):
            handles.append(Line2D([], [], ls="", marker="D", mfc=colour, mec=INK, ms=6, mew=0.8))
            labels.append(f"chokepoint {text}")
    ax.legend(handles, labels, loc="upper right", frameon=False, fontsize=font, labelcolor=INK_2, borderaxespad=0.2)


@_house_style
def plot_network(instance: str | Path | Instance = "tiny", detailed: bool = False, ax=None) -> Figure:
    """The instance as a graph (module docstring); drawn on ``ax`` when given, else on a new figure. Returns the figure.

    ``instance`` is a packaged instance name, an instance file path, or an ``Instance``.
    """
    inst = instance if isinstance(instance, Instance) else load_instance(instance)
    tables = _tables(inst)
    if ax is None:
        fig = Figure(figsize=(13.0, 7.0) if detailed else (10.5, 5.6), dpi=110, facecolor=SURFACE)
        FigureCanvasAgg(fig)
        ax = fig.add_axes((0.01, 0.02, 0.84, 0.9))
    fig = ax.figure
    _draw_map(ax, tables, detailed=detailed, legend="kinds", font=7.5)
    ax.set_title(
        f"{inst.instance_id}: {len(inst.nodes)} nodes, {len(inst.edges)} edges, T = {inst.T} weeks"
        + ("  (edge labels: capacity u0 per week · lead time τ in weeks · freight \\$ per unit)" if detailed else ""),
        fontsize=9,
        color=INK,
        loc="left",
    )
    return fig


# ----------------------------------------------------------------------------------------------------------------------
# the episode figure


def _chokepoint_open(rec: Mapping, config: dict) -> np.ndarray:
    """(T, chokepoints) open fractions of weeks 1..T, NaN where unobserved."""
    T = config["T"]
    return _seen(rec, "graph_now.open")[:T]


def _states(rec: Mapping, config: dict) -> list[list[str]]:
    return [edge_states_flat(config["static"], _week(rec, t)) for t in range(1, config["T"] + 1)]


def _focus_week(rec: Mapping, config: dict) -> int:
    """The week the least open chokepoint is least open; without a closure, the week with most closed edges; else 1."""
    opens = _chokepoint_open(rec, config)
    low = np.nanmin(np.where(np.isnan(opens), np.inf, opens), axis=1) if opens.size else np.full(config["T"], np.inf)
    if np.isfinite(low).any() and low.min() < 1 - EPS:
        return int(np.argmin(low)) + 1
    closed = [s.count("closed") for s in _states(rec, config)]
    return int(np.argmax(closed)) + 1 if max(closed, default=0) else 1


def _money(x: float, _pos=None) -> str:
    a = abs(x)
    if a >= 1e9:
        return f"\\${x / 1e9:.1f}B"
    if a >= 1e6:
        return f"\\${x / 1e6:.1f}M"
    if a >= 1e3:
        return f"\\${x / 1e3:.0f}k"
    return f"\\${x:.0f}"


def _style(ax, font: float = 7.0) -> None:
    """Recessive chrome: hairline y grid, muted axes, no top or right spine."""
    ax.set_facecolor(SURFACE)
    for side in ("top", "right"):
        ax.spines[side].set_visible(False)
    for side in ("left", "bottom"):
        ax.spines[side].set_color(AXIS)
    ax.tick_params(colors=MUTED, labelsize=font, labelcolor=INK_2, length=2)
    ax.grid(axis="y", color=GRID, lw=0.6)
    ax.set_axisbelow(True)


def _title(ax, text: str, font: float = 8.0) -> None:
    ax.set_title(text, fontsize=font, color=INK, loc="left")


def _cursor(ax, week: int) -> None:
    ax.axvline(week, color=MUTED, lw=0.8, zorder=0)


def _names(config: dict) -> dict:
    st = config["static"]
    return {"node": st["nodes"]["id"], "k": st["commodities"]["id"], "units": st.get("units", {})}


def _panel_open(ax, rec, config, week: int, font: float, upto: int | None = None) -> None:
    T, names = config["T"], _names(config)
    weeks = np.arange(1, T + 1)
    opens = _chokepoint_open(rec, config)
    chk = config["layout"]["chokepoints"]
    for j, c in enumerate(chk):
        colour = SERIES[j % len(SERIES)] if len(chk) > 1 else INK
        if upto is None:
            ax.step(weeks, opens[:, j], where="mid", color=colour, lw=1.6, label=names["node"][c])
        else:
            ax.step(weeks, opens[:, j], where="mid", color=colour, lw=1.0, alpha=0.25)
            ax.step(weeks[:upto], opens[:upto, j], where="mid", color=colour, lw=1.8, label=names["node"][c])
    ax.set_ylim(-0.05, 1.08)
    ax.set_xlim(0.5, T + 0.5)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda v, _p: f"{v:.0%}"))
    _style(ax, font)
    _cursor(ax, week)
    if len(chk) > 1:
        ax.legend(fontsize=font - 1, frameon=False, loc="lower left", labelcolor=INK_2)
    name = f"chokepoint {names['node'][chk[0]]}" if len(chk) == 1 else "chokepoint"
    _title(ax, f"{name}: open fraction (observed)", font + 1)


def _panel_warning(ax, rec, config, week: int, font: float) -> None:
    T, names = config["T"], _names(config)
    weeks = np.arange(1, T + 1)
    score = _seen(rec, "warning.score")[:T]
    units = config["layout"]["warning_units"]
    others = [i for i, (kind, _u) in enumerate(units) if kind != "chokepoint"]
    for n, i in enumerate(others):
        ax.plot(weeks, score[:, i], color=AXIS, lw=0.7, label="regions and dyads" if n == 0 else None)
    chk = [(i, u) for i, (kind, u) in enumerate(units) if kind == "chokepoint"]
    for j, (i, c) in enumerate(chk):
        colour = SERIES[j % len(SERIES)]
        ax.plot(weeks, score[:, i], color=colour, lw=1.8, label=f"chokepoint {names['node'][c]}")
    ax.axhline(0, color=AXIS, lw=0.8)
    ax.set_xlim(0.5, T + 0.5)
    _style(ax, font)
    _cursor(ax, week)
    ax.legend(fontsize=font - 1, frameon=False, loc="best", ncol=2, labelcolor=INK_2)
    ax.set_xlabel("week", fontsize=font, color=INK_2)
    _title(ax, "warning score (a noisy signal, every week)", font + 1)


def _panel_stock(fig, ax, rec, config, week: int, font: float) -> None:
    T, names = config["T"], _names(config)
    stock = _seen(rec, "stock.qty")[:T].T  # (slots, weeks)
    top = np.nanmax(np.where(np.isnan(stock), -np.inf, stock), axis=1)
    scale = np.where(np.isfinite(top) & (top > 0), top, 1.0)
    shown = stock / scale[:, None]
    cmap = STOCK_MAP.with_extremes(bad=GRID)
    im = ax.imshow(
        shown,
        aspect="auto",
        cmap=cmap,
        vmin=0,
        vmax=1,
        interpolation="nearest",
        extent=(0.5, T + 0.5, len(shown) - 0.5, -0.5),
    )
    slots = config["layout"]["stock_slots"]
    ax.set_yticks(range(len(slots)))
    ax.set_yticklabels([f"{names['node'][n]} {names['k'][k]}" for n, k in slots], fontsize=font - 1)
    for r, m in enumerate(top):
        ax.text(
            T + 0.7, r, "–" if not np.isfinite(m) else _fmt(float(m)), va="center", fontsize=font - 1.5, color=MUTED
        )
    ax.set_xlabel("week", fontsize=font, color=INK_2)
    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
    ax.tick_params(colors=MUTED, labelsize=font, labelcolor=INK_2, length=2)
    for side in ax.spines.values():
        side.set_visible(False)
    _cursor(ax, week)
    bar = fig.colorbar(im, ax=ax, fraction=0.025, pad=0.06)
    bar.ax.tick_params(labelsize=font - 1, colors=MUTED, labelcolor=INK_2)
    bar.outline.set_visible(False)
    bar.set_label("share of the row's episode maximum (right)", fontsize=font - 1, color=INK_2)
    _title(ax, "stock by node and commodity, start of each week", font + 1)


def _panel_shipped(ax, rec, config, week: int, font: float) -> None:
    T, names = config["T"], _names(config)
    weeks = np.arange(1, T + 1)
    shipped = _shipped({k: rec[f"obs/{k}"] for k in ("last_week.clip.executed", "last_week.clip.executed.observed")})
    slot_k = np.asarray(config["static"]["action_slots"]["k"])
    for k, kid in enumerate(names["k"]):
        if not (slot_k == k).any():
            continue
        series = shipped[:, slot_k == k].sum(axis=1)
        unit = names["units"].get(kid, "")
        ax.plot(weeks, series, color=SERIES[k % len(SERIES)], lw=1.6, label=f"{kid} ({unit})" if unit else kid)
    ax.set_yscale("symlog", linthresh=1.0)
    ax.set_xlim(0.5, T + 0.5)
    _style(ax, font)
    _cursor(ax, week)
    ax.legend(fontsize=font - 1, frameon=False, loc="best", labelcolor=INK_2)
    ax.set_xlabel("week", fontsize=font, color=INK_2)
    _title(ax, "units shipped per week, by commodity (log scale above 1)", font + 1)


def _panel_costs(ax, rec, config, week: int, font: float) -> None:
    T = config["T"]
    weeks = np.arange(1, T + 1)
    cost = np.asarray(rec["cost"], dtype=np.float64)
    names = [str(c) for c in rec["cost_components"]]
    base = np.zeros(T)
    for j, name in enumerate(names):
        if not cost[:, j].any():
            continue  # a component that never charged takes no legend entry; its colour stays its own
        ax.bar(weeks, cost[:, j], bottom=base, width=0.78, color=SERIES[j % len(SERIES)], label=name, lw=0)
        base += cost[:, j]
    ax.yaxis.set_major_formatter(FuncFormatter(_money))
    ax.set_xlim(0.5, T + 0.5)
    _style(ax, font)
    _cursor(ax, week)
    ax.legend(fontsize=font - 1, frameon=False, loc="upper left", ncol=4, labelcolor=INK_2)
    ax.set_xlabel("week", fontsize=font, color=INK_2)
    _title(ax, "weekly cost by component", font + 1)


def _cumulative(reward_cents: np.ndarray) -> np.ndarray:
    """Cumulative cost net of the terminal credit: the sum of -r_t, which ends at J (USD)."""
    return np.cumsum(-np.asarray(reward_cents, dtype=np.int64)) / 100


def _panel_cumulative(ax, rec, config, week: int, font: float, upto: int | None = None, agent: str = "agent") -> None:
    T = config["T"]
    weeks = np.arange(1, T + 1)
    lines = [(agent, _cumulative(rec["reward_cents"]), SERIES[0])]
    if "naive/reward_cents" in rec:
        lines.append(("naive", _cumulative(rec["naive/reward_cents"]), SERIES[1]))
    for name, series, colour in lines:
        if upto is None:
            ax.plot(weeks, series, color=colour, lw=1.8, label=f"{name}: J {_money(series[-1])}")
        else:
            ax.plot(weeks, series, color=colour, lw=1.0, alpha=0.25)
            ax.plot(weeks[:upto], series[:upto], color=colour, lw=1.8, label=f"{name} {_money(series[upto - 1])}")
    ax.yaxis.set_major_formatter(FuncFormatter(_money))
    ax.set_xlim(0.5, T + 0.5)
    _style(ax, font)
    _cursor(ax, week)
    ax.legend(fontsize=font - 1, frameon=False, loc="upper left", labelcolor=INK_2)
    ax.set_xlabel("week", fontsize=font, color=INK_2)
    what = (
        "cumulative cost against naive" if "naive/reward_cents" in rec else "cumulative cost (no naive in the record)"
    )
    _title(ax, f"{what}; week T takes the terminal credit", font + 1)


def _phrase(signal: str, group: list[dict]) -> str:
    """One signal's events of one week as a short phrase."""
    e = group[0]
    if signal == "chokepoint":
        return "; ".join(
            f"{x['subject']} open {x['after']:.0%}"
            if x["before"] is None
            else f"{x['subject']} open {x['before']:.0%}→{x['after']:.0%}"
            for x in group
        )
    if signal in ("prohibited", "lifted") and len(group) <= 2:
        return "; ".join(f"{x['subject']} {signal}" for x in group)
    if signal == "war_risk":
        return f"{e['subject']} war risk {e['before']}→{e['after']}"
    if signal == "closure_end":
        return f"{e['subject']} closure end announced (week {e['after']})"
    if signal == "pending" and len(group) == 1:
        return f"{e['subject']} prohibition pending (week {e['after']})"
    if signal == "message" and len(group) == 1:
        return f"{e['subject']} ({e['note'].split(', ', 1)[-1]})"
    words = {  # signal -> (singular, plural)
        "prohibited": ("prohibition in force", "prohibitions in force"),
        "lifted": ("prohibition lifted", "prohibitions lifted"),
        "pending": ("prohibition pending", "prohibitions pending"),
        "message": ("announcement", "announcements"),
        "capacity": ("capacity change", "capacity changes"),
        "tariff": ("tariff change", "tariff changes"),
        "fab": ("fab restoration change", "fab restoration changes"),
        "osat": ("OSAT restoration change", "OSAT restoration changes"),
        "grid": ("grid generation change", "grid generation changes"),
        "supply": ("supply change", "supply changes"),
        "message_update": ("announcement update", "announcement updates"),
        "message_ended": ("announcement ended", "announcements ended"),
    }
    one, many = words.get(signal, (signal, signal))
    return f"{len(group)} {one if len(group) == 1 else many}"


def timeline_lines(events: list[dict], T: int, max_weeks: int = MAX_TIMELINE_WEEKS) -> list[str]:
    """The text strip: one line per week with events, the ``max_weeks`` most eventful weeks (salient signals first)."""
    by_week: dict[int, dict[str, list[dict]]] = {}
    for e in events:
        if 1 <= e["week"] <= T:
            by_week.setdefault(e["week"], {}).setdefault(e["signal"], []).append(e)
    rank = {s: i for i, s in enumerate(TIMELINE_ORDER)}
    lines = {}
    for w, signals in by_week.items():
        ordered = sorted(signals, key=lambda s: rank.get(s, len(rank)))
        lines[w] = f"wk {w:>2}  " + " · ".join(_phrase(s, signals[s]) for s in ordered)
    score = {
        w: (sum(len(v) for s, v in sig.items() if s in SALIENT), sum(len(v) for v in sig.values()))
        for w, sig in by_week.items()
    }
    keep = sorted(sorted(lines, key=lambda w: score[w], reverse=True)[:max_weeks])
    out = [lines[w] for w in keep]
    if len(lines) > len(keep):
        out.append(f"… and {len(lines) - len(keep)} more weeks with minor changes")
    return out


def _panel_timeline(ax, rec, config, font: float) -> None:
    lines = timeline_lines(rec["events"], config["T"])
    ax.set_axis_off()
    _title(ax, "timeline: what the agent could see change (shockbench_flow_gym.timeline)", font + 1)
    if not lines:
        ax.text(0, 1, "no disruption signal changed in this episode", fontsize=font, color=INK_2, va="top")
        return
    half = math.ceil(len(lines) / 2)
    width = 118  # characters per column line (a display choice)
    for col, chunk in enumerate((lines[:half], lines[half:])):
        text = "\n".join(line if len(line) <= width else line[: width - 1] + "…" for line in chunk)
        ax.text(
            0.5 * col,
            1.0,
            text,
            fontsize=font - 0.5,
            family="monospace",
            color=INK_2,
            va="top",
            ha="left",
            transform=ax.transAxes,
            linespacing=1.35,
        )


def _open_by_node(rec: Mapping, config: dict, week: int) -> dict[int, float]:
    opens = _chokepoint_open(rec, config)[week - 1]
    return {int(c): float(o) for c, o in zip(config["layout"]["chokepoints"], opens)}


def _panel_map(ax, rec, config, week: int, font: float, legend: str | None = "states") -> None:
    states = edge_states_flat(config["static"], _week(rec, week))
    open_frac = _open_by_node(rec, config, week)
    _draw_map(ax, config["static"], states=states, open_frac=open_frac, legend=legend, font=font)
    closed, reduced = states.count("closed"), states.count("reduced")
    shown = [f"{o:.0%}" for o in open_frac.values() if np.isfinite(o)]
    _title(
        ax,
        f"week {week}: chokepoint open {', '.join(shown) or 'unobserved'} · {closed} edges closed · {reduced} reduced"
        " (the state observed at the start of the week)",
        font + 1,
    )


def _check_week(week: int | None, T: int) -> None:
    if week is not None and (isinstance(week, bool) or not isinstance(week, (int, np.integer)) or not 1 <= week <= T):
        raise ValueError(f"week must be an integer in 1..{T} (a decision week), got {week!r}")


@_house_style
def episode_dashboard(record, path: str | Path | None = None, *, week: int | None = None, dpi: int = 90) -> Figure:
    """The multi-panel figure of one episode (module docstring); written to ``path`` (PNG, or by suffix) when given.

    ``record`` is a record (``record_episode``) or its ``.npz`` path; ``week`` (1..T) the week the map shows, by
    default the week the least open chokepoint is least open.

    Raises:
        ValueError: on a record of another format or a week outside 1..T.

    """
    rec, config = _view(record)
    T = config["T"]
    _check_week(week, T)
    week = _focus_week(rec, config) if week is None else int(week)
    font = 7.5
    fig = Figure(figsize=(16, 13.5), dpi=dpi, facecolor=SURFACE)
    FigureCanvasAgg(fig)
    grid = fig.add_gridspec(
        4, 3, height_ratios=(3.3, 2.7, 2.2, 1.9), hspace=0.42, wspace=0.28, left=0.08, right=0.97, top=0.93, bottom=0.02
    )
    right = grid[0, 2].subgridspec(2, 1, hspace=0.35)
    _panel_map(fig.add_subplot(grid[0, :2]), rec, config, week, font)
    ax_open = fig.add_subplot(right[0])
    _panel_open(ax_open, rec, config, week, font)
    _panel_warning(fig.add_subplot(right[1], sharex=ax_open), rec, config, week, font)
    _panel_stock(fig, fig.add_subplot(grid[1, :2]), rec, config, week, font)
    _panel_shipped(fig.add_subplot(grid[1, 2]), rec, config, week, font)
    _panel_costs(fig.add_subplot(grid[2, :2]), rec, config, week, font)
    agent = str(rec["agent"])
    _panel_cumulative(fig.add_subplot(grid[2, 2]), rec, config, week, font, agent=agent)
    _panel_timeline(fig.add_subplot(grid[3, :]), rec, config, font)
    episode = rec["episode"]
    J = int(rec["J_cents"]) / 100
    naive = f" · naive J {_money(int(rec['naive/J_cents']) / 100)}" if "naive/J_cents" in rec else ""
    fig.suptitle(
        f"{agent} on {rec['instance']}"
        + ("" if episode is None else f", episode {episode}")
        + f" · regime {rec['regime']} · J {_money(J)}{naive}"
        + "  (J: total cost less the terminal credit; lower is better)",
        fontsize=11,
        color=INK,
        x=0.08,
        ha="left",
    )
    if path is not None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(path, dpi=dpi, facecolor=SURFACE)
    return fig


# ----------------------------------------------------------------------------------------------------------------------
# the animation


def _frame(rec: Mapping, config: dict, week: int, dpi: int) -> "np.ndarray":
    """One GIF frame: the map at ``week``, the open fraction and the cumulative cost up to it (uint8 RGB)."""
    font = 6.5
    fig = Figure(figsize=(9.6, 5.0), dpi=dpi, facecolor=SURFACE)
    canvas = FigureCanvasAgg(fig)
    grid = fig.add_gridspec(
        2, 2, width_ratios=(1.55, 1), hspace=0.5, wspace=0.12, left=0.01, right=0.97, top=0.88, bottom=0.1
    )
    _panel_map(fig.add_subplot(grid[:, 0]), rec, config, week, font, legend=None)
    ax_open = fig.add_subplot(grid[0, 1])
    _panel_open(ax_open, rec, config, week, font, upto=week)
    agent = str(rec["agent"])
    _panel_cumulative(fig.add_subplot(grid[1, 1]), rec, config, week, font, upto=week, agent=agent)
    fig.suptitle(
        f"{agent} on {rec['instance']} · week {week} of {config['T']}", fontsize=9, color=INK, x=0.02, ha="left"
    )
    canvas.draw()
    return np.asarray(canvas.buffer_rgba())[:, :, :3].copy()


@_house_style
def episode_animation(record, path: str | Path, *, fps: float = 2.0, dpi: int = 80, colors: int = 96) -> Path:
    """A GIF of the episode, one frame per week 1..T (module docstring), written by Pillow; returns its path.

    ``fps`` frames per second, ``dpi`` the frame resolution and ``colors`` the palette size of each frame (display
    choices: the defaults keep a 26-week ``tiny`` GIF near a megabyte).
    """
    from PIL import Image  # Pillow comes with matplotlib

    rec, config = _view(record)
    frames = [
        Image.fromarray(_frame(rec, config, t, dpi)).quantize(colors=colors, method=Image.Quantize.MEDIANCUT)
        for t in range(1, config["T"] + 1)
    ]
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    buf = io.BytesIO()
    frames[0].save(buf, format="GIF", save_all=True, append_images=frames[1:], duration=int(1000 / fps), loop=0)
    path.write_bytes(buf.getvalue())
    return path
