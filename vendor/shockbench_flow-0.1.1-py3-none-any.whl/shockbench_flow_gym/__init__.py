"""The gymnasium adapter of ShockBench-Flow (design §9.1, §12 "Gymnasium adapter (M3 wire)"; Q68, Q95).

A sibling package in the wheel, installed with the ``gym`` extra (gymnasium, and matplotlib and networkx for the
render); ``shockbench_flow`` never imports it. ``ShockBenchFlowEnv`` wraps ``shockbench_flow.dynamics.env.Env`` with
the flat view of ``shockbench_flow.information.flat``; ``shockbench_flow_gym.timeline`` lists what changes week to week
in the disruption signals of its observations (the hackathon starter guide's episode finder).

Importing the package registers one gymnasium id per public task (``registration.register_envs``):
``gym.make("ShockBench/Tiny-v0", regime="standard", dense_reward=False, render_mode=None)``, each ``reset(seed=s)``
drawing a scenario of the public generator (the dev root by default, ``entropy=`` one's own).

The submodules ``wrappers`` (the RL wrappers and the episode recorder) and ``dashboard`` (the network map, the episode
dashboard and its GIF) load on first use, ``shockbench_flow_gym.wrappers`` as ``from shockbench_flow_gym import
wrappers``, so importing the package loads neither (the dashboard imports matplotlib).
"""

import importlib

from shockbench_flow_gym.env import ShockBenchFlowEnv, potential_cents
from shockbench_flow_gym.registration import make_env, register_envs


ENV_IDS = register_envs()
_SUBMODULES = ("dashboard", "render", "timeline", "wrappers")

__all__ = ["ENV_IDS", "ShockBenchFlowEnv", "make_env", "potential_cents", "register_envs"]


def __getattr__(name: str):
    """``shockbench_flow_gym.<submodule>`` for the submodules of ``_SUBMODULES``, imported on first use."""
    if name in _SUBMODULES:
        return importlib.import_module(f"{__name__}.{name}")
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
