"""``ShockBenchFlowEnv``: a ``gymnasium.Env`` over the package's ``Env`` and its flat view (design §9.1, §3.6).

Readings of design §12 "Gymnasium adapter (M3 wire)":

- ``omega_source`` is an omega (or its path), played every episode, or a callable of the episode index n, which
  ``reset(seed=)`` draws from ``np_random`` (``integers(0, 2**31)``), a seeded reset making it
  ``Generator(PCG64DXSM(SeedSequence(seed)))`` (the §4.1 rule table), so a seed repeats its episode;
  ``reset(options={"episode": n})`` plays episode n of a callable source instead (the index is still drawn, so the
  seeded stream of later resets is the same), which replays the scenario an ``info["episode"]`` named.
- The observation is ``flat.flatten_obs`` plus ``action_mask`` and ``action_mask.observed``, then ``override_mask``
  and ``override_mask.observed`` (``flat.observation_arrays``; M5 re-gate INT-M5R-03), its messages block the
  live threads only (``flat.live_messages``, Q105) while ``info['obs']`` keeps the cumulative list; the action is a
  ``Dict`` of ``flows`` and ``override_qty`` (``Box`` on [0, inf)) and ``release_mode`` (``MultiDiscrete`` 3 per
  pair), turned into the §9.2 action by ``flat.action_from_flat``. An episode whose layout differs from the first
  raises. The padded lists take the instance kind's caps (``flat.maxima_for``: `tiny`'s ``DEFAULT_MAXIMA``, `small`
  and `full` their own; M5 stream "wire"), which ``maxima`` overrides block by block; a list over its cap raises,
  never truncated. On `small` and `full` the pipeline block carries its groups (``flat.group_rows``, padded to its
  structural bound; M5-O35 (c)) and the queue lots are the dense (lot key, arrival week) block of ``flat.dense_lots``
  (M5-O38 (b); its rows ``env.layout.lot_keys``), while ``info['obs']`` keeps the §9.2 lists.
- Reward: r_t / (100 reward_scale), r_t the integer cents of (25) (``info['reward_cents']``); ``reward_scale`` 1.0
  by default: the measured per-instance scales, naive's mean weekly cost on the dev split, are
  ``wrappers.REWARD_SCALE_USD``, which ``wrappers.ScaleReward`` divides by with this one left at 1 (§9.1).
  The dense form (``dense_reward=True``) is §3.6's
  r~^¢_t = -C^¢_t + Phi^¢(s_t) - Phi^¢(s_{t-1}), with Phi^¢(s_t) for t < T the (24) cents of (23)'s salvage terms read
  from the observation's own state (``potential_cents``) and Phi^¢(s_T) = S^¢_T from the Env, so the dense cents sum
  to -J^¢ - Phi^¢(s_0) exactly (``info['dense_cents']``).
- ``fallback`` None: a flat action is always well formed, so no week takes the D9 fallback; ``info`` carries the Env's
  info and the §9.2 observation (``obs``), and at reset the Env's reset info (``static``, ``policy_seed``, and
  ``omega`` under clairvoyant: full omega at reset, which the flat view cannot carry; M3 attempt 1's gate, INT-M3-04)
  and the episode index. The ``obs`` and ``static`` handed out are the caller's, never the adapter's own state (the
  Env builds both afresh and keeps neither): the adapter keeps the week for the next action, a deep copy of Static,
  and a deep copy of the observation only under ``render_mode='rgb_array'``, so editing them changes no later week
  and no render (M3 attempt 1's gate, DET-M3-3).
- ``render()`` (mode ``rgb_array``) draws the last observation and Static only (``shockbench_flow_gym.render``).
"""

import copy
import math
from collections import defaultdict
from collections.abc import Callable
from pathlib import Path

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from shockbench_flow.dynamics.env import Env
from shockbench_flow.dynamics.state import cents
from shockbench_flow.information.flat import RELEASE_MODES, FlatLayout, action_from_flat, observation_arrays
from shockbench_flow.instance import load_instance
from shockbench_flow.instance.schema import Instance
from shockbench_flow.omega.container import Omega


INT_BOUND = 2**31  # bounds of the int64 boxes (indices, weeks, codes), a space bound, not a model value
EPISODES = 2**31  # the episode indices reset draws from np_random


def potential_cents(inst: Instance, obs: dict) -> int:
    """Phi^¢ of §3.6 at the observation's instant: the (24) cents of (23)'s salvage terms of its own state.

    Stock at nu (0 at supply nodes), each chokepoint queue (the exact sum of its lots) at the chokepoint slot's nu,
    each (edge, commodity, arrival week) of the pipeline (the exact sum of its shipments) at the nu of the edge's head,
    fab WIP at the nu of its input and OSAT WIP at the nu of its raw input; the terms summed by ``math.fsum``.
    """
    supply = set(inst.supply_nodes)

    def nu(node: int, k: int) -> float:
        s = inst.slot_index.get((node, k))
        return 0.0 if node in supply or s is None else inst.stock_slots[s].salvage

    terms = [nu(n, k) * q for n, k, q in zip(obs["stock"]["node"], obs["stock"]["k"], obs["stock"]["qty"])]
    queues, transit = defaultdict(list), defaultdict(list)
    lots = obs["queue_lots"]
    for c, k, q in zip(lots["chokepoint"], lots["k"], lots["qty"]):
        queues[(c, k)].append(q)
    terms += [nu(c, k) * math.fsum(qs) for (c, k), qs in queues.items()]
    pipe = obs["pipeline"]
    for e, k, w, q in zip(pipe["edge"], pipe["k"], pipe["arrival_week"], pipe["qty"]):
        transit[(e, k, w)].append(q)
    terms += [nu(inst.edges[e].head, k) * math.fsum(qs) for (e, k, _w), qs in transit.items()]
    fabs, osats = set(inst.fabs), set(inst.osats)
    for n, k, q in zip(obs["wip"]["node"], obs["wip"]["k"], obs["wip"]["qty"]):
        if n in fabs:
            terms.append(nu(n, inst.nodes[n].fab.input) * q)
        elif n in osats:
            raw_of = {pk: raw for raw, pk in inst.nodes[n].osat.packages.items()}
            terms.append(nu(n, raw_of[k]) * q)
    return cents(math.fsum(terms))


def _box(sample: np.ndarray) -> spaces.Box:
    if sample.dtype == np.float64:
        return spaces.Box(-np.inf, np.inf, sample.shape, np.float64)
    if sample.dtype == np.int8:
        return spaces.Box(0, 1, sample.shape, np.int8)
    return spaces.Box(-INT_BOUND, INT_BOUND - 1, sample.shape, np.int64)


class ShockBenchFlowEnv(gym.Env):
    """One ShockBench-Flow instance as a gymnasium environment (module docstring)."""

    metadata = {"render_modes": ["rgb_array"], "render_fps": 4}

    def __init__(
        self,
        instance: str | Path | Instance = "tiny",
        omega_source: Omega | str | Path | Callable[[int], Omega | str | Path] | None = None,
        regime: str = "prediction_free",
        *,
        fallback=None,
        reward_scale: float = 1.0,
        dense_reward: bool = False,
        maxima: dict[str, int] | None = None,
        policy_seed: int = 0,
        render_mode: str | None = None,
    ) -> None:
        """Build the environment and its spaces from the first episode's Static (episode index 0).

        ``maxima`` None pads every list to the instance kind's cap (``flat.maxima_for``); a dict overrides those caps
        block by block (``flat.FlatLayout.from_static``, which refuses a cap below a structural bound).

        Raises:
            ValueError: without an omega source, on a reward scale that is not a positive finite number, an unknown
                render mode, or a cap ``FlatLayout.from_static`` refuses.

        """
        if omega_source is None:
            raise ValueError("omega_source: an omega, its path, or a callable of the episode index is required")
        if not (isinstance(reward_scale, (int, float)) and math.isfinite(reward_scale) and reward_scale > 0):
            raise ValueError(f"reward_scale must be a positive finite number, got {reward_scale!r}")
        if render_mode is not None and render_mode not in self.metadata["render_modes"]:
            raise ValueError(f"render_mode must be None or one of {self.metadata['render_modes']}, got {render_mode!r}")
        self.instance = instance if isinstance(instance, Instance) else load_instance(instance)
        self.omega_source, self.regime, self.policy_seed = omega_source, regime, policy_seed
        self.reward_scale, self.dense_reward, self.maxima = float(reward_scale), dense_reward, maxima
        self.render_mode = render_mode
        self.core = Env(fallback=fallback)
        obs, info = self.core.reset(self.instance, regime, self._omega(0), policy_seed)
        self.layout = FlatLayout.from_static(info["static"], maxima, inst=self.instance)
        self._static, self._phi = info["static"], None  # the first episode's, handed to no caller
        self._keep(obs)
        sample = observation_arrays(self.layout, obs)
        self.observation_space = spaces.Dict([(k, _box(v)) for k, v in sample.items()])
        self.action_space = spaces.Dict(
            [
                ("flows", spaces.Box(0.0, np.inf, (self.layout.n_slots,), np.float64)),
                ("override_qty", spaces.Box(0.0, np.inf, (self.layout.n_override_slots,), np.float64)),
                ("release_mode", spaces.MultiDiscrete([len(RELEASE_MODES)] * len(self.layout.pairs))),
            ]
        )

    def _omega(self, n: int):
        return self.omega_source(n) if callable(self.omega_source) else self.omega_source

    def _episode_option(self, n) -> int:
        """The episode index of ``options['episode']``, checked (reset's docstring)."""
        if isinstance(n, bool) or not isinstance(n, (int, np.integer)) or n < 0:
            raise ValueError(f"options['episode'] must be an integer >= 0, got {n!r}")
        if not callable(self.omega_source):
            raise ValueError("options['episode'] needs a callable omega source (a fixed omega plays every episode)")
        return int(n)

    def _keep(self, obs: dict) -> None:
        """Keep what the adapter reads later: the week (the next action's), and a private copy of ``obs`` to render."""
        self._week = obs["week"]
        self._obs = copy.deepcopy(obs) if self.render_mode == "rgb_array" else None

    def reset(self, *, seed: int | None = None, options: dict | None = None):
        """Start the episode whose index ``np_random`` draws; (flat obs, the Env's reset info, ``obs``, ``episode``).

        ``options={"episode": n}`` plays episode n of a callable omega source (module docstring).

        Raises:
            ValueError: if the episode's flat layout is not the first episode's (another dyad count), or on an
                ``episode`` option that is not an integer >= 0 or with a fixed omega source.

        """
        super().reset(seed=seed)
        if seed is not None:  # an explicit PCG64DXSM of the seed (§4.1 rule table), where gymnasium seeds a PCG64
            self._np_random = np.random.Generator(np.random.PCG64DXSM(np.random.SeedSequence(seed)))
        n = int(self.np_random.integers(0, EPISODES))
        if options and options.get("episode") is not None:
            n = self._episode_option(options["episode"])
        obs, info = self.core.reset(self.instance, self.regime, self._omega(n), self.policy_seed)
        if FlatLayout.from_static(info["static"], self.maxima, inst=self.instance) != self.layout:
            raise ValueError(f"episode {n}: its flat layout differs from the first episode's (spaces are fixed)")
        self._static = copy.deepcopy(info["static"])  # the render's; the caller gets the Env's fresh Static
        self._keep(obs)
        self._phi = potential_cents(self.instance, obs) if self.dense_reward else None
        out = {**info, "obs": obs, "episode": n}  # the Env's obs, Static and omega are fresh per reset, never kept here
        return observation_arrays(self.layout, obs), out

    def step(self, action: dict):
        """Step one week with the flat ``action``; (flat obs, reward, terminated, truncated, info).

        ``override_qty`` and ``release_mode`` may be left out (zeros: the default release), as the agent kit's shim
        reads a Dict action (``shockbench_flow_agent.convert.action_to_wire``); ``flows`` may not.
        """
        override_qty, modes = action.get("override_qty"), action.get("release_mode")
        a = action_from_flat(
            self.layout,
            self._week,
            action["flows"],
            np.zeros(self.layout.n_override_slots) if override_qty is None else override_qty,
            np.zeros(len(self.layout.pairs), dtype=np.int64) if modes is None else modes,
        )
        obs, _reward, terminated, truncated, info = self.core.step(a)
        r_cents = info["reward_cents"]
        info["obs"] = obs  # the caller's: the Env built it afresh, and the adapter keeps only its week (``_keep``)
        if self.dense_reward:  # §3.6: -C^¢_t + Phi^¢(s_t) - Phi^¢(s_{t-1}), Phi^¢(s_T) = S^¢_T
            salvage = info["salvage_cents"] if terminated else 0
            phi = info["salvage_cents"] if terminated else potential_cents(self.instance, obs)
            info["dense_cents"] = r_cents - salvage + phi - self._phi
            self._phi = phi
            r_cents = info["dense_cents"]
        self._keep(obs)
        return observation_arrays(self.layout, obs), r_cents / (100 * self.reward_scale), terminated, truncated, info

    def render(self):
        """The network state of the last observation as an uint8 (H, W, 3) image (Obs and Static only), or None."""
        if self.render_mode != "rgb_array":
            return None
        from shockbench_flow_gym.render import draw

        return draw(self._static, self._obs)
