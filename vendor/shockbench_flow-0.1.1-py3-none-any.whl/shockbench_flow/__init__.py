"""ShockBench-Flow: the portable benchmark package (design `docs/design.md`; phase 3).

It depends on numpy, scipy (HiGHS), the standard library and the libraries that suit it (Q94 (c): joblib for the
parallel loops, fastjsonschema for the instance file's closed schema, Q95), and never imports hydra (CLAUDE.md).
"""

__version__ = "0.1.1"
