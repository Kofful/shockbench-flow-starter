"""``python -m shockbench_flow_agent <submission dir>``: the policy container's entry point (``shim.serve_submission``).

Exit status 0 at the end of the input, ``shim.IMPORT_FAILED`` (2) when ``agent.py`` cannot be imported, 64 on a usage
error.
"""

import sys

from shockbench_flow_agent.shim import serve_submission


USAGE = 64  # EX_USAGE of sysexits.h


def main(argv: list[str]) -> int:
    if len(argv) != 1:
        print("usage: python -m shockbench_flow_agent <submission directory or agent.py>", file=sys.stderr)
        return USAGE
    return serve_submission(argv[0])


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
