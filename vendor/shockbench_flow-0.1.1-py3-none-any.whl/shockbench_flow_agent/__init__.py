"""The agent kit of ShockBench-Flow's competition layer (design §9.1-§9.4; Q102).

A sibling package in the wheel, as ``shockbench_flow_gym`` is; ``shockbench_flow`` imports it only inside the functions
of ``policies.kit_agents`` (the kit's own agents as registry policies, the M5 pilot's participant-like entries), never
at module level. Two sides:

- the policy container's shim (``shim``, ``convert``): a participant's ``Agent`` behind the §9.2 wire, run as
  ``python -m shockbench_flow_agent <submission dir>``; it imports numpy, the wire codec and the flat view only, and
  does its first-use work before the ready line (``warm_up``, which the image's build check also runs);
- the submission validator (``submission``): a re-export of the trusted runner's own (``hosting.submission``, stdlib
  only), safe zip extraction and a static check of ``agent.py`` that never imports participant code, so a local check
  refuses what the runner refuses.

``spaces`` documents the Dict observation and action field by field from the flat layout (the hackathon README).

``evaluate`` (and ``report``) score an agent locally on a public task's dev episodes (``local_eval``, the scoring core
of ``scripts/python/eval_submission.py``), and ``EpisodeSet`` (``scoring``) builds a fixed episode set with its
reference costs cached for search loops (``score``, ``compare``, a bootstrap interval, an optional CPU meter); they are
loaded on first use, never by the container's shim, since they import the simulator, the oracle and naive's F_Q
(SciPy). The console scripts ``sbf-validate`` and ``sbf-eval`` are ``cli``.
"""

from shockbench_flow_agent.convert import action_to_wire, agent_config, observation_dict
from shockbench_flow_agent.shim import (
    AGENT_FILE,
    IMPORT_FAILED,
    AgentShim,
    load_agent_class,
    serve,
    serve_submission,
    unload_agent,
    warm_up,
)


__all__ = [
    "AGENT_FILE",
    "IMPORT_FAILED",
    "AgentShim",
    "action_to_wire",
    "agent_config",
    "load_agent_class",
    "observation_dict",
    "serve",
    "serve_submission",
    "unload_agent",
    "warm_up",
    "evaluate",
    "report",
    "EpisodeSet",
    "Score",
    "Comparison",
]
# names imported on first use (module docstring): local_eval's and scoring's, which import the simulator
_LAZY = {
    "evaluate": "local_eval",
    "report": "local_eval",
    "EpisodeSet": "scoring",
    "Score": "scoring",
    "Comparison": "scoring",
}


def __getattr__(name: str):
    if name in _LAZY:
        import importlib

        return getattr(importlib.import_module(f"shockbench_flow_agent.{_LAZY[name]}"), name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
